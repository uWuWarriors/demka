﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UP12._01
{
    public static class RoleClass
    {
        public static string userRole;
        public static string userFIO;
        public static string userGender;
        public static DateTime userTime;
    }
}
