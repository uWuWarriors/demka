﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UP12._01
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        КонференцииEntities confaEntities = new КонференцииEntities();
        int status = 0;
        public MainWindow()
        {
            InitializeComponent();
            NapravlenieBox.ItemsSource = confaEntities.Направления.Select(p => p.Направление).ToList();
            DataBox.ItemsSource = confaEntities.Мероприятия.Select(p => p.Дата_проведения).ToList();
        }

        private void DataBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DataBox.Text=="") NapravlenieBox.IsEnabled = false;
            status = 1;
        }

        private void NapravlenieBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (NapravlenieBox.Text == "") DataBox.IsEnabled = false;
            status = 2;
        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            if (status == 2)
            {
                int checkedNapravlenie = NapravlenieBox.SelectedIndex + 2;
                DG.ItemsSource = confaEntities.Мероприятия.Where(p => p.Код_направления == checkedNapravlenie).ToList();
                NapravlenieBox.Text = null;
                DataBox.IsEnabled = true;
                status = 0;
            } 
            else if (status == 1)
            {
                DateTime dataSelect = Convert.ToDateTime(DataBox.Text);
                DG.ItemsSource = confaEntities.Мероприятия.Where(p => p.Дата_проведения == dataSelect).ToList();
                DataBox.Text = null;
                NapravlenieBox.IsEnabled = true;
                status = 0;
            }
        }

        private void btnAuth_Click(object sender, RoutedEventArgs e)
        {
            AuthWindow authWindow = new AuthWindow();
            authWindow.Show();
            this.Close();
        }        
    }
}
