﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UP12._01
{
    /// <summary>
    /// Логика взаимодействия для OrganizatorWindow.xaml
    /// </summary>
    public partial class OrganizatorWindow : Window
    {

        TimeSpan началоУтра = new TimeSpan(9, 0, 0);
        TimeSpan конецУтра = new TimeSpan(11, 0, 0);

        TimeSpan началоДня = new TimeSpan(11, 01, 0);
        TimeSpan конецДня = new TimeSpan(18, 0, 0);

        TimeSpan началоВечера = new TimeSpan(18, 01, 0);
        TimeSpan конецВечера = new TimeSpan(23, 59, 59);

        TimeSpan началоНочи = new TimeSpan(0, 1, 0);
        TimeSpan конецНочи = new TimeSpan(8, 59, 0);

        public OrganizatorWindow()
        {
            InitializeComponent();
            if (RoleClass.userTime.TimeOfDay >= началоУтра && RoleClass.userTime.TimeOfDay <= конецУтра) SetTimeOfDay.Content = "Доброе утро!";
            if (RoleClass.userTime.TimeOfDay >= началоДня && RoleClass.userTime.TimeOfDay <= конецДня) SetTimeOfDay.Content = "Добрый день!";
            if (RoleClass.userTime.TimeOfDay >= началоВечера && RoleClass.userTime.TimeOfDay <= конецВечера) SetTimeOfDay.Content = "Добрый вечер!";
            if (RoleClass.userTime.TimeOfDay >= началоНочи && RoleClass.userTime.TimeOfDay <= конецНочи) SetTimeOfDay.Content = "Доброй ночи!";

            if (RoleClass.userGender == "мужской") SetName.Content = "Mr " + RoleClass.userFIO;
            else if (RoleClass.userGender == "женский") SetName.Content = "Mrs " + RoleClass.userFIO;
        }

        private void btnJuri_Click(object sender, RoutedEventArgs e)
        {
            JuriWindow juriWindow = new JuriWindow();
            juriWindow.Show();
            this.Close();
        }
    }
}
