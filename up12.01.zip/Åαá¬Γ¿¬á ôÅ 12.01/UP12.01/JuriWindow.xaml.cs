﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UP12._01
{
    /// <summary>
    /// Логика взаимодействия для JuriWindow.xaml
    /// </summary>
    public partial class JuriWindow : Window
    {

        КонференцииEntities confaEntities = new КонференцииEntities();
        Пользователи newUser = new Пользователи();
        МодераторыМероприятия newModMer = new МодераторыМероприятия();

        public JuriWindow()
        {
            InitializeComponent();

            int lastModer = confaEntities.Пользователи.Max(p => p.Код_пользователя);
            int NumberOfNewUser = lastModer + 1;

            checkElement.IsEnabled = false;
            MeropriyatieBox.IsEnabled = false;

            NumberText.Text = NumberOfNewUser.ToString();

            NapravleniyeBox.ItemsSource = confaEntities.Направления.ToList();
            MeropriyatieBox.ItemsSource = confaEntities.Мероприятия.ToList();
            CountryBox.ItemsSource = confaEntities.Страны.ToList();
        }


        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (FirstPasswordText.Text == SecondPasswordText.Text)
            {
                if (RoleText.Text == "модератор")
                {
                    newUser.ФИО = FIOText.Text;
                    newUser.Пол = GenderBox.Text;
                    newUser.Почта = EmailText.Text;
                    newUser.Код_страны = CountryBox.SelectedIndex + 1;
                    newUser.Телефон = PhoneText.Text;
                    newUser.Код_направления = NapravleniyeBox.SelectedIndex + 2;
                    newUser.Код_роли = 2;
                    newUser.Пароль = FirstPasswordText.Text;

                    confaEntities.Пользователи.Add(newUser);
                    confaEntities.SaveChanges();

                    if (MeropriyatieBox.Text != "")
                    {
                        int lastModer = confaEntities.Пользователи.Max(p => p.Код_пользователя);
                        newModMer.Код_модератора = lastModer;
                        newModMer.Код_мероприятия = confaEntities.Мероприятия.Where(p => p.Событие == MeropriyatieBox.Text).Select(p => p.Код_мероприятия).FirstOrDefault();
                        confaEntities.МодераторыМероприятия.Add(newModMer);
                        confaEntities.SaveChanges();
                    }
                    
                    MessageBox.Show("Успешно добавлен новый пользователь - модератор!");
                }

                else if (RoleText.Text == "жюри")
                {
                    newUser.ФИО = FIOText.Text;
                    newUser.Пол = GenderBox.Text;
                    newUser.Почта = EmailText.Text;
                    newUser.Код_страны = CountryBox.SelectedIndex + 1;
                    newUser.Телефон = PhoneText.Text;
                    newUser.Код_направления = NapravleniyeBox.SelectedIndex + 2;
                    newUser.Код_роли = 3;
                    newUser.Пароль = FirstPasswordText.Text;
                    confaEntities.Пользователи.Add(newUser);
                    confaEntities.SaveChanges();
                    MessageBox.Show("Успешно добавлен новый пользователь - жюри!");

                }                
            }

            else MessageBox.Show("Пароли не совпадают!");

            OrganizatorWindow organizatorWindow = new OrganizatorWindow();
            organizatorWindow.Show();
            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            OrganizatorWindow organizatorWindow = new OrganizatorWindow();
            organizatorWindow.Show();
            this.Close();
        }

        private void RoleText_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RoleText.SelectedIndex == 1)
            {
                checkElement.IsEnabled = true;
                MeropriyatieBox.IsEnabled = true;
            }
            else if (RoleText.SelectedIndex == 0)
            {
                checkElement.IsChecked = false;
                checkElement.IsEnabled = false;
                MeropriyatieBox.Text = "";
                MeropriyatieBox.IsEnabled = false;
            }
        }

        private void checkElement_Checked(object sender, RoutedEventArgs e)
        {
            //if (checkElement.IsChecked == true) MeropriyatieBox.IsEnabled = true;
            //else MeropriyatieBox.IsEnabled = false;
        }
    }
}
