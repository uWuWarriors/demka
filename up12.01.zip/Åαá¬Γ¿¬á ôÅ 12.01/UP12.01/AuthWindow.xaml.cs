﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UP12._01
{
    /// <summary>
    /// Логика взаимодействия для AuthWindow.xaml
    /// </summary>
    public partial class AuthWindow : Window
    {

        КонференцииEntities konfEntities = new КонференцииEntities();
        public AuthWindow()
        {
            InitializeComponent();
        }

        private void btnAuth_Click(object sender, RoutedEventArgs e)
        {
            int login = Convert.ToInt32(NumberText.Text);
            string password = PasswordText.Text;

            if (konfEntities.Пользователи.Where(p => p.Код_пользователя == login && p.Пароль == password && p.Роли.Наименование == "Организатор").FirstOrDefault() != null)
            {
                MessageBox.Show("Добро пожаловать, " + konfEntities.Пользователи.Where(p => p.Код_пользователя == login && p.Пароль == password).Select(p => p.ФИО).FirstOrDefault().ToString());
                RoleClass.userFIO = konfEntities.Пользователи.Where(p => p.Код_пользователя == login && p.Пароль == password).Select(p => p.ФИО).FirstOrDefault().ToString();
                RoleClass.userGender = konfEntities.Пользователи.Where(p => p.Код_пользователя == login && p.Пароль == password).Select(p => p.Пол).FirstOrDefault().ToString();
                RoleClass.userRole = konfEntities.Пользователи.Where(p => p.Код_пользователя == login && p.Пароль == password).Select(p => p.Роли.Наименование).FirstOrDefault().ToString();
                RoleClass.userTime = DateTime.Now;
                OrganizatorWindow organizatorWindow = new OrganizatorWindow();
                organizatorWindow.Show();
                this.Close();
            }

            else if (konfEntities.Пользователи.Where(p => p.Код_пользователя == login && p.Пароль == password && p.Роли.Наименование == "Модератор").FirstOrDefault() != null)
            {
                MessageBox.Show("Вы авторизовались под учетной записью с ролью модератора.");
            }

            else if (konfEntities.Пользователи.Where(p => p.Код_пользователя == login && p.Пароль == password && p.Роли.Наименование == "Жюри").FirstOrDefault() != null)
            {
                MessageBox.Show("Вы авторизовались под учетной записью с ролью жюри.");
            }

            else if (konfEntities.Пользователи.Where(p => p.Код_пользователя == login && p.Пароль == password && p.Роли.Наименование == "Участник").FirstOrDefault() != null)
            {
                MessageBox.Show("Вы авторизовались под учетной записью с ролью участника.");
            }

            else MessageBox.Show("Данные некорректны");

            



        }
    }
}
