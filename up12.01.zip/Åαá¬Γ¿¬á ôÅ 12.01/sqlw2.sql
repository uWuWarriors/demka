USE [master]
GO
/****** Object:  Database [Конференции]    Script Date: 23.03.2024 9:34:46 ******/
CREATE DATABASE [Конференции]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'Конференции', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\Конференции.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'Конференции_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\Конференции_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
ALTER DATABASE [Конференции] SET COMPATIBILITY_LEVEL = 160
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Конференции].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Конференции] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [Конференции] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [Конференции] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [Конференции] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [Конференции] SET ARITHABORT OFF 
GO
ALTER DATABASE [Конференции] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [Конференции] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [Конференции] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [Конференции] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [Конференции] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [Конференции] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [Конференции] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [Конференции] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [Конференции] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [Конференции] SET  DISABLE_BROKER 
GO
ALTER DATABASE [Конференции] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [Конференции] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [Конференции] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [Конференции] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [Конференции] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [Конференции] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [Конференции] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [Конференции] SET RECOVERY FULL 
GO
ALTER DATABASE [Конференции] SET  MULTI_USER 
GO
ALTER DATABASE [Конференции] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [Конференции] SET DB_CHAINING OFF 
GO
ALTER DATABASE [Конференции] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [Конференции] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [Конференции] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [Конференции] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
EXEC sys.sp_db_vardecimal_storage_format N'Конференции', N'ON'
GO
ALTER DATABASE [Конференции] SET QUERY_STORE = ON
GO
ALTER DATABASE [Конференции] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [Конференции]
GO
/****** Object:  Table [dbo].[Активности]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Активности](
	[Код_активности] [int] IDENTITY(1,1) NOT NULL,
	[Наименование] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_Активности] PRIMARY KEY CLUSTERED 
(
	[Код_активности] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[АктивностиМероприятия]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[АктивностиМероприятия](
	[Код_активности_мероприятия] [int] IDENTITY(1,1) NOT NULL,
	[Код_активности] [int] NOT NULL,
	[Код_мероприятия] [int] NOT NULL,
 CONSTRAINT [PK_АктивностиМероприятия] PRIMARY KEY CLUSTERED 
(
	[Код_активности_мероприятия] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Города]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Города](
	[Код] [int] IDENTITY(1,1) NOT NULL,
	[Код_города] [int] NOT NULL,
	[Герб] [nvarchar](50) NULL,
	[Наименование] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Города] PRIMARY KEY CLUSTERED 
(
	[Код] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ЖюриАктивности]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ЖюриАктивности](
	[Код_жюри_активности] [int] IDENTITY(1,1) NOT NULL,
	[Код_активности] [int] NOT NULL,
	[Код_жюри] [int] NOT NULL,
 CONSTRAINT [PK_ЖюриАктивности] PRIMARY KEY CLUSTERED 
(
	[Код_жюри_активности] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Мероприятия]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Мероприятия](
	[Код_мероприятия] [int] IDENTITY(1,1) NOT NULL,
	[Событие] [nvarchar](max) NOT NULL,
	[Дата_проведения] [date] NOT NULL,
	[Дни] [int] NOT NULL,
	[Код_города_проведения] [int] NOT NULL,
	[Код_направления] [int] NULL,
 CONSTRAINT [PK_Мероприятия] PRIMARY KEY CLUSTERED 
(
	[Код_мероприятия] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[МодераторыМероприятия]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[МодераторыМероприятия](
	[Код_модератора_мероприятия] [int] IDENTITY(1,1) NOT NULL,
	[Код_модератора] [int] NOT NULL,
	[Код_мероприятия] [int] NOT NULL,
 CONSTRAINT [PK_МодераторыМероприятия] PRIMARY KEY CLUSTERED 
(
	[Код_модератора_мероприятия] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Направления]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Направления](
	[Код_направления] [int] IDENTITY(1,1) NOT NULL,
	[Направление] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Направления] PRIMARY KEY CLUSTERED 
(
	[Код_направления] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Пользователи]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Пользователи](
	[Код_пользователя] [int] IDENTITY(1,1) NOT NULL,
	[ФИО] [nvarchar](max) NOT NULL,
	[Пол] [nvarchar](max) NOT NULL,
	[Почта] [nvarchar](max) NOT NULL,
	[Дата_рождения] [date] NULL,
	[Код_страны] [int] NULL,
	[Телефон] [nvarchar](50) NOT NULL,
	[Код_направления] [int] NULL,
	[Пароль] [nvarchar](50) NOT NULL,
	[Фото] [nvarchar](50) NULL,
	[Код_роли] [int] NULL,
 CONSTRAINT [PK_Пользователи] PRIMARY KEY CLUSTERED 
(
	[Код_пользователя] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Роли]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Роли](
	[Код_роли] [int] IDENTITY(1,1) NOT NULL,
	[Наименование] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Роли] PRIMARY KEY CLUSTERED 
(
	[Код_роли] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Страны]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Страны](
	[Код] [int] IDENTITY(1,1) NOT NULL,
	[Код_страны] [int] NOT NULL,
	[Наименование] [nvarchar](150) NOT NULL,
	[Английское_название_страны] [nvarchar](max) NOT NULL,
	[Буквенный_код_страны] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Страны_1] PRIMARY KEY CLUSTERED 
(
	[Код] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[УчастникиМероприятия]    Script Date: 23.03.2024 9:34:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[УчастникиМероприятия](
	[Код_участников_мероприятия] [int] NOT NULL,
	[Код_мероприятия] [int] NOT NULL,
	[Код_участника] [int] NOT NULL,
 CONSTRAINT [PK_УчастникиМероприятия] PRIMARY KEY CLUSTERED 
(
	[Код_участников_мероприятия] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Активности] ON 
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (1, N'Лидерство в бизнесе')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (2, N'Технология принятия решений')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (3, N'Искусство коучинга')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (4, N'Переговоры от "А" до "Я"')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (5, N'Телефонные переговоры')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (6, N'Навыки подготовки')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (7, N'Новые продукты и версии')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (8, N'Big Data')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (9, N'Must Have 21 века')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (10, N'Управление знаниями')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (11, N'Коммуникативные неудачи')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (12, N'Дизайн-мышление')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (13, N'Технические собеседования')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (14, N'Исследование рынка')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (15, N'Рекрутинг')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (16, N'Kanban')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (17, N'Способы поиска специалистов')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (18, N'Роли HR')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (19, N'Осознанность личных целей')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (20, N'Soft skills')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (21, N'Развитие проактивности')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (22, N'Введение в IT-субкультуру')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (23, N'Управление знаниями')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (24, N'Развитие проактивности')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (25, N'Идельный результат')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (26, N'Тайны и секреты')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (27, N'Рычаги')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (28, N'Войти в ТОП')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (29, N'Секреты продвижения')
GO
INSERT [dbo].[Активности] ([Код_активности], [Наименование]) VALUES (30, N'Руководство проектами')
GO
SET IDENTITY_INSERT [dbo].[Активности] OFF
GO
SET IDENTITY_INSERT [dbo].[АктивностиМероприятия] ON 
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (1, 1, 3)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (2, 2, 3)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (3, 3, 3)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (4, 4, 4)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (5, 5, 4)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (6, 6, 4)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (7, 7, 5)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (8, 8, 5)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (9, 9, 5)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (10, 10, 6)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (11, 11, 6)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (12, 12, 6)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (13, 13, 7)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (14, 14, 7)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (15, 15, 7)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (16, 16, 8)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (17, 17, 8)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (18, 18, 8)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (19, 19, 9)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (20, 20, 10)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (21, 21, 11)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (22, 22, 12)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (23, 23, 13)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (24, 24, 14)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (25, 25, 15)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (26, 26, 16)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (28, 27, 17)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (29, 28, 18)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (30, 29, 19)
GO
INSERT [dbo].[АктивностиМероприятия] ([Код_активности_мероприятия], [Код_активности], [Код_мероприятия]) VALUES (31, 30, 20)
GO
SET IDENTITY_INSERT [dbo].[АктивностиМероприятия] OFF
GO
SET IDENTITY_INSERT [dbo].[Города] ON 
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1, 2, NULL, N'Абакан')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (2, 3, NULL, N'Абдулино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (3, 4, NULL, N'Абинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (4, 5, NULL, N'Агидель')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (5, 6, NULL, N'Агрыз')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (6, 7, NULL, N'Адыгейск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (7, 8, NULL, N'Азнакаево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (8, 9, NULL, N'Азов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (9, 10, NULL, N'Ак-Довурак')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (10, 11, NULL, N'Аксай')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (11, 12, NULL, N'Алагир')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (12, 13, NULL, N'Алапаевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (13, 14, NULL, N'Алатырь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (14, 15, NULL, N'Алдан')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (15, 16, NULL, N'Алейск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (16, 17, NULL, N'Александров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (17, 18, NULL, N'Александровск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (18, 19, NULL, N'Александровск-Сахалинский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (19, 20, NULL, N'Алексеевка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (20, 21, NULL, N'Алексин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (21, 22, NULL, N'Алзамай')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (22, 23, NULL, N'Алупкане призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (23, 24, NULL, N'Алуштане призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (24, 25, NULL, N'Альметьевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (25, 26, NULL, N'Амурск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (26, 27, NULL, N'Анадырь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (27, 28, NULL, N'Анапа')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (28, 29, NULL, N'Ангарск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (29, 30, NULL, N'Андреаполь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (30, 31, NULL, N'Анжеро-Судженск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (31, 32, NULL, N'Анива')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (32, 33, NULL, N'Апатиты')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (33, 34, NULL, N'Апрелевка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (34, 35, NULL, N'Апшеронск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (35, 36, NULL, N'Арамиль')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (36, 37, NULL, N'Аргун')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (37, 38, NULL, N'Ардатов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (38, 39, NULL, N'Ардон')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (39, 40, NULL, N'Арзамас')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (40, 41, NULL, N'Аркадак')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (41, 42, NULL, N'Армавир')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (42, 43, NULL, N'Армянскне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (43, 44, NULL, N'Арсеньев')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (44, 45, NULL, N'Арск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (45, 46, NULL, N'Артём')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (46, 47, NULL, N'Артёмовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (47, 48, NULL, N'Артёмовский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (48, 49, NULL, N'Архангельск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (49, 50, NULL, N'Асбест')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (50, 51, NULL, N'Асино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (51, 52, NULL, N'Астрахань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (52, 53, NULL, N'Аткарск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (53, 54, NULL, N'Ахтубинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (54, 55, NULL, N'Ачинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (55, 56, NULL, N'Аша')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (56, 57, NULL, N'Бабаево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (57, 58, NULL, N'Бабушкин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (58, 59, NULL, N'Бавлы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (59, 60, NULL, N'Багратионовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (60, 61, NULL, N'Байкальск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (61, 62, NULL, N'Баймак')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (62, 63, NULL, N'Бакал')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (63, 64, NULL, N'Баксан')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (64, 65, NULL, N'Балабаново')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (65, 66, NULL, N'Балаково')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (66, 67, NULL, N'Балахна')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (67, 68, NULL, N'Балашиха')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (68, 69, NULL, N'Балашов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (69, 70, NULL, N'Балей')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (70, 71, NULL, N'Балтийск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (71, 72, NULL, N'Барабинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (72, 73, NULL, N'Барнаул')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (73, 74, NULL, N'Барыш')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (74, 75, NULL, N'Батайск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (75, 76, NULL, N'Бахчисарайне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (76, 77, NULL, N'Бежецк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (77, 78, NULL, N'Белая Калитва')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (78, 79, NULL, N'Белая Холуница')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (79, 80, NULL, N'Белгород')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (80, 81, NULL, N'Белебей')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (81, 82, NULL, N'Белёв')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (82, 83, NULL, N'Белинский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (83, 84, NULL, N'Белово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (84, 85, NULL, N'Белогорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (85, 86, NULL, N'Белогорскне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (86, 87, NULL, N'Белозерск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (87, 88, NULL, N'Белокуриха')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (88, 89, NULL, N'Беломорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (89, 90, NULL, N'Белоозёрский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (90, 91, NULL, N'Белорецк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (91, 92, NULL, N'Белореченск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (92, 93, NULL, N'Белоусово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (93, 94, NULL, N'Белоярский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (94, 95, NULL, N'Белый')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (95, 96, NULL, N'Бердск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (96, 97, NULL, N'Березники')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (97, 98, NULL, N'Берёзовский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (98, 99, NULL, N'Берёзовский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (99, 100, NULL, N'Беслан')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (100, 101, NULL, N'Бийск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (101, 102, NULL, N'Бикин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (102, 103, NULL, N'Билибино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (103, 104, NULL, N'Биробиджан')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (104, 105, NULL, N'Бирск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (105, 106, NULL, N'Бирюсинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (106, 107, NULL, N'Бирюч')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (107, 108, NULL, N'Благовещенск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (108, 109, NULL, N'Благовещенск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (109, 110, NULL, N'Благодарный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (110, 111, NULL, N'Бобров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (111, 112, NULL, N'Богданович')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (112, 113, NULL, N'Богородицк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (113, 114, NULL, N'Богородск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (114, 115, NULL, N'Боготол')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (115, 116, NULL, N'Богучар')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (116, 117, NULL, N'Бодайбо')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (117, 118, NULL, N'Бокситогорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (118, 119, NULL, N'Болгар')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (119, 120, NULL, N'Бологое')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (120, 121, NULL, N'Болотное')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (121, 122, NULL, N'Болохово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (122, 123, NULL, N'Болхов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (123, 124, NULL, N'Большой Камень')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (124, 125, NULL, N'Бор')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (125, 126, NULL, N'Борзя')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (126, 127, NULL, N'Борисоглебск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (127, 128, NULL, N'Боровичи')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (128, 129, NULL, N'Боровск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (129, 130, NULL, N'Бородино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (130, 131, NULL, N'Братск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (131, 132, NULL, N'Бронницы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (132, 133, NULL, N'Брянск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (133, 134, NULL, N'Бугульма')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (134, 135, NULL, N'Бугуруслан')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (135, 136, NULL, N'Будённовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (136, 137, NULL, N'Бузулук')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (137, 138, NULL, N'Буинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (138, 139, NULL, N'Буй')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (139, 140, NULL, N'Буйнакск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (140, 141, NULL, N'Бутурлиновка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (141, 142, NULL, N'Валдай')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (142, 143, NULL, N'Валуйки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (143, 144, NULL, N'Велиж')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (144, 145, NULL, N'Великие Луки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (145, 146, NULL, N'Великий Новгород')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (146, 147, NULL, N'Великий Устюг')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (147, 148, NULL, N'Вельск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (148, 149, NULL, N'Венёв')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (149, 150, NULL, N'Верещагино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (150, 151, NULL, N'Верея')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (151, 152, NULL, N'Верхнеуральск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (152, 153, NULL, N'Верхний Тагил')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (153, 154, NULL, N'Верхний Уфалей')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (154, 155, NULL, N'Верхняя Пышма')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (155, 156, NULL, N'Верхняя Салда')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (156, 157, NULL, N'Верхняя Тура')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (157, 158, NULL, N'Верхотурье')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (158, 159, NULL, N'Верхоянск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (159, 160, NULL, N'Весьегонск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (160, 161, NULL, N'Ветлуга')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (161, 162, NULL, N'Видное')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (162, 163, NULL, N'Вилюйск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (163, 164, NULL, N'Вилючинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (164, 165, NULL, N'Вихоревка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (165, 166, NULL, N'Вичуга')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (166, 167, NULL, N'Владивосток')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (167, 168, NULL, N'Владикавказ')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (168, 169, NULL, N'Владимир')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (169, 170, NULL, N'Волгоград')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (170, 171, NULL, N'Волгодонск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (171, 172, NULL, N'Волгореченск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (172, 173, NULL, N'Волжск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (173, 174, NULL, N'Волжский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (174, 175, NULL, N'Вологда')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (175, 176, NULL, N'Володарск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (176, 177, NULL, N'Волоколамск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (177, 178, NULL, N'Волосово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (178, 179, NULL, N'Волхов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (179, 180, NULL, N'Волчанск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (180, 181, NULL, N'Вольск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (181, 182, NULL, N'Воркута')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (182, 183, NULL, N'Воронеж')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (183, 184, NULL, N'Ворсма')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (184, 185, NULL, N'Воскресенск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (185, 186, NULL, N'Воткинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (186, 187, NULL, N'Всеволожск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (187, 188, NULL, N'Вуктыл')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (188, 189, NULL, N'Выборг')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (189, 190, NULL, N'Выкса')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (190, 191, NULL, N'Высоковск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (191, 192, NULL, N'Высоцк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (192, 193, NULL, N'Вытегра')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (193, 194, NULL, N'Вышний Волочёк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (194, 195, NULL, N'Вяземский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (195, 196, NULL, N'Вязники')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (196, 197, NULL, N'Вязьма')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (197, 198, NULL, N'Вятские Поляны')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (198, 199, NULL, N'Гаврилов Посад')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (199, 200, NULL, N'Гаврилов-Ям')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (200, 201, NULL, N'Гагарин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (201, 202, NULL, N'Гаджиево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (202, 203, NULL, N'Гай')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (203, 204, NULL, N'Галич')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (204, 205, NULL, N'Гатчина')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (205, 206, NULL, N'Гвардейск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (206, 207, NULL, N'Гдов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (207, 208, NULL, N'Геленджик')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (208, 209, NULL, N'Георгиевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (209, 210, NULL, N'Глазов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (210, 211, NULL, N'Голицыно')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (211, 212, NULL, N'Горбатов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (212, 213, NULL, N'Горно-Алтайск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (213, 214, NULL, N'Горнозаводск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (214, 215, NULL, N'Горняк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (215, 216, NULL, N'Городец')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (216, 217, NULL, N'Городище')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (217, 218, NULL, N'Городовиковск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (218, 219, NULL, N'Гороховец')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (219, 220, NULL, N'Горячий Ключ')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (220, 221, NULL, N'Грайворон')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (221, 222, NULL, N'Гремячинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (222, 223, NULL, N'Грозный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (223, 224, NULL, N'Грязи')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (224, 225, NULL, N'Грязовец')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (225, 226, NULL, N'Губаха')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (226, 227, NULL, N'Губкин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (227, 228, NULL, N'Губкинский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (228, 229, NULL, N'Гудермес')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (229, 230, NULL, N'Гуково')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (230, 231, NULL, N'Гулькевичи')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (231, 232, NULL, N'Гурьевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (232, 233, NULL, N'Гурьевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (233, 234, NULL, N'Гусев')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (234, 235, NULL, N'Гусиноозёрск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (235, 236, NULL, N'Гусь-Хрустальный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (236, 237, NULL, N'Давлеканово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (237, 238, NULL, N'Дагестанские Огни')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (238, 239, NULL, N'Далматово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (239, 240, NULL, N'Дальнегорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (240, 241, NULL, N'Дальнереченск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (241, 242, NULL, N'Данилов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (242, 243, NULL, N'Данков')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (243, 244, NULL, N'Дегтярск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (244, 245, NULL, N'Дедовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (245, 246, NULL, N'Демидов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (246, 247, NULL, N'Дербент')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (247, 248, NULL, N'Десногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (248, 249, NULL, N'Джанкойне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (249, 250, NULL, N'Дзержинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (250, 251, NULL, N'Дзержинский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (251, 252, NULL, N'Дивногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (252, 253, NULL, N'Дигора')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (253, 254, NULL, N'Димитровград')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (254, 255, NULL, N'Дмитриев')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (255, 256, NULL, N'Дмитров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (256, 257, NULL, N'Дмитровск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (257, 258, NULL, N'Дно')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (258, 259, NULL, N'Добрянка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (259, 260, NULL, N'Долгопрудный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (260, 261, NULL, N'Долинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (261, 262, NULL, N'Домодедово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (262, 263, NULL, N'Донецк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (263, 264, NULL, N'Донской')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (264, 265, NULL, N'Дорогобуж')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (265, 266, NULL, N'Дрезна')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (266, 267, NULL, N'Дубна')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (267, 268, NULL, N'Дубовка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (268, 269, NULL, N'Дудинка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (269, 270, NULL, N'Духовщина')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (270, 271, NULL, N'Дюртюли')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (271, 272, NULL, N'Дятьково')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (272, 273, NULL, N'Евпаторияне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (273, 274, NULL, N'Егорьевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (274, 275, NULL, N'Ейск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (275, 276, NULL, N'Екатеринбург')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (276, 277, NULL, N'Елабуга')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (277, 278, NULL, N'Елец')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (278, 279, NULL, N'Елизово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (279, 280, NULL, N'Ельня')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (280, 281, NULL, N'Еманжелинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (281, 282, NULL, N'Емва')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (282, 283, NULL, N'Енисейск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (283, 284, NULL, N'Ермолино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (284, 285, NULL, N'Ершов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (285, 286, NULL, N'Ессентуки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (286, 287, NULL, N'Ефремов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (287, 288, NULL, N'Железноводск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (288, 289, NULL, N'Железногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (289, 290, NULL, N'Железногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (290, 291, NULL, N'Железногорск-Илимский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (291, 292, NULL, N'Жердевка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (292, 293, NULL, N'Жигулёвск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (293, 294, NULL, N'Жиздра')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (294, 295, NULL, N'Жирновск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (295, 296, NULL, N'Жуков')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (296, 297, NULL, N'Жуковка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (297, 298, NULL, N'Жуковский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (298, 299, NULL, N'Завитинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (299, 300, NULL, N'Заводоуковск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (300, 301, NULL, N'Заволжск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (301, 302, NULL, N'Заволжье')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (302, 303, NULL, N'Задонск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (303, 304, NULL, N'Заинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (304, 305, NULL, N'Закаменск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (305, 306, NULL, N'Заозёрный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (306, 307, NULL, N'Заозёрск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (307, 308, NULL, N'Западная Двина')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (308, 309, NULL, N'Заполярный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (309, 310, NULL, N'Зарайск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (310, 311, NULL, N'Заречный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (311, 312, NULL, N'Заречный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (312, 313, NULL, N'Заринск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (313, 314, NULL, N'Звенигово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (314, 315, NULL, N'Звенигород')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (315, 316, NULL, N'Зверево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (316, 317, NULL, N'Зеленогорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (317, 318, NULL, N'Зеленоградск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (318, 319, NULL, N'Зеленодольск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (319, 320, NULL, N'Зеленокумск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (320, 321, NULL, N'Зерноград')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (321, 322, NULL, N'Зея')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (322, 323, NULL, N'Зима')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (323, 324, NULL, N'Златоуст')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (324, 325, NULL, N'Злынка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (325, 326, NULL, N'Змеиногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (326, 327, NULL, N'Знаменск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (327, 328, NULL, N'Зубцов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (328, 329, NULL, N'Зуевка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (329, 330, NULL, N'Ивангород')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (330, 331, NULL, N'Иваново')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (331, 332, NULL, N'Ивантеевка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (332, 333, NULL, N'Ивдель')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (333, 334, NULL, N'Игарка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (334, 335, NULL, N'Ижевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (335, 336, NULL, N'Избербаш')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (336, 337, NULL, N'Изобильный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (337, 338, NULL, N'Иланский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (338, 339, NULL, N'Инза')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (339, 340, NULL, N'Иннополис')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (340, 341, NULL, N'Инсар')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (341, 342, NULL, N'Инта')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (342, 343, NULL, N'Ипатово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (343, 344, NULL, N'Ирбит')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (344, 345, NULL, N'Иркутск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (345, 346, NULL, N'Исилькуль')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (346, 347, NULL, N'Искитим')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (347, 348, NULL, N'Истра')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (348, 349, NULL, N'Ишим')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (349, 350, NULL, N'Ишимбай')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (350, 351, NULL, N'Йошкар-Ола')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (351, 352, NULL, N'Кадников')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (352, 353, NULL, N'Казань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (353, 354, NULL, N'Калач')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (354, 355, NULL, N'Калач-на-Дону')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (355, 356, NULL, N'Калачинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (356, 357, NULL, N'Калининград')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (357, 358, NULL, N'Калининск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (358, 359, NULL, N'Калтан')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (359, 360, NULL, N'Калуга')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (360, 361, NULL, N'Калязин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (361, 362, NULL, N'Камбарка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (362, 363, NULL, N'Каменка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (363, 364, NULL, N'Каменногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (364, 365, NULL, N'Каменск-Уральский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (365, 366, NULL, N'Каменск-Шахтинский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (366, 367, NULL, N'Камень-на-Оби')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (367, 368, NULL, N'Камешково')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (368, 369, NULL, N'Камызяк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (369, 370, NULL, N'Камышин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (370, 371, NULL, N'Камышлов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (371, 372, NULL, N'Канаш')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (372, 373, NULL, N'Кандалакша')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (373, 374, NULL, N'Канск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (374, 375, NULL, N'Карабаново')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (375, 376, NULL, N'Карабаш')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (376, 377, NULL, N'Карабулак')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (377, 378, NULL, N'Карасук')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (378, 379, NULL, N'Карачаевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (379, 380, NULL, N'Карачев')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (380, 381, NULL, N'Каргат')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (381, 382, NULL, N'Каргополь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (382, 383, NULL, N'Карпинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (383, 384, NULL, N'Карталы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (384, 385, NULL, N'Касимов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (385, 386, NULL, N'Касли')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (386, 387, NULL, N'Каспийск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (387, 388, NULL, N'Катав-Ивановск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (388, 389, NULL, N'Катайск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (389, 390, NULL, N'Качканар')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (390, 391, NULL, N'Кашин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (391, 392, NULL, N'Кашира')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (392, 393, NULL, N'Кедровый')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (393, 394, NULL, N'Кемерово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (394, 395, NULL, N'Кемь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (395, 396, NULL, N'Керчьне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (396, 397, NULL, N'Кизел')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (397, 398, NULL, N'Кизилюрт')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (398, 399, NULL, N'Кизляр')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (399, 400, NULL, N'Кимовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (400, 401, NULL, N'Кимры')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (401, 402, NULL, N'Кингисепп')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (402, 403, NULL, N'Кинель')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (403, 404, NULL, N'Кинешма')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (404, 405, NULL, N'Киреевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (405, 406, NULL, N'Киренск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (406, 407, NULL, N'Киржач')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (407, 408, NULL, N'Кириллов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (408, 409, NULL, N'Кириши')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (409, 410, NULL, N'Киров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (410, 411, NULL, N'Киров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (411, 412, NULL, N'Кировград')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (412, 413, NULL, N'Кирово-Чепецк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (413, 414, NULL, N'Кировск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (414, 415, NULL, N'Кировск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (415, 416, NULL, N'Кирс')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (416, 417, NULL, N'Кирсанов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (417, 418, NULL, N'Киселёвск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (418, 419, NULL, N'Кисловодск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (419, 420, NULL, N'Клин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (420, 421, NULL, N'Клинцы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (421, 422, NULL, N'Княгинино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (422, 423, NULL, N'Ковдор')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (423, 424, NULL, N'Ковров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (424, 425, NULL, N'Ковылкино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (425, 426, NULL, N'Когалым')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (426, 427, NULL, N'Кодинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (427, 428, NULL, N'Козельск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (428, 429, NULL, N'Козловка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (429, 430, NULL, N'Козьмодемьянск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (430, 431, NULL, N'Кола')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (431, 432, NULL, N'Кологрив')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (432, 433, NULL, N'Коломна')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (433, 434, NULL, N'Колпашево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (434, 435, NULL, N'Кольчугино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (435, 436, NULL, N'Коммунар')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (436, 437, NULL, N'Комсомольск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (437, 438, NULL, N'Комсомольск-на-Амуре')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (438, 439, NULL, N'Конаково')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (439, 440, NULL, N'Кондопога')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (440, 441, NULL, N'Кондрово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (441, 442, NULL, N'Константиновск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (442, 443, NULL, N'Копейск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (443, 444, NULL, N'Кораблино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (444, 445, NULL, N'Кореновск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (445, 446, NULL, N'Коркино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (446, 447, NULL, N'Королёв')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (447, 448, NULL, N'Короча')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (448, 449, NULL, N'Корсаков')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (449, 450, NULL, N'Коряжма')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (450, 451, NULL, N'Костерёво')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (451, 452, NULL, N'Костомукша')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (452, 453, NULL, N'Кострома')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (453, 454, NULL, N'Котельники')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (454, 455, NULL, N'Котельниково')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (455, 456, NULL, N'Котельнич')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (456, 457, NULL, N'Котлас')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (457, 458, NULL, N'Котово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (458, 459, NULL, N'Котовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (459, 460, NULL, N'Кохма')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (460, 461, NULL, N'Красавино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (461, 462, NULL, N'Красноармейск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (462, 463, NULL, N'Красноармейск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (463, 464, NULL, N'Красновишерск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (464, 465, NULL, N'Красногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (465, 466, NULL, N'Краснодар')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (466, 467, NULL, N'Краснозаводск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (467, 468, NULL, N'Краснознаменск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (468, 469, NULL, N'Краснознаменск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (469, 470, NULL, N'Краснокаменск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (470, 471, NULL, N'Краснокамск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (471, 472, NULL, N'Красноперекопскне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (472, 473, NULL, N'Краснослободск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (473, 474, NULL, N'Краснослободск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (474, 475, NULL, N'Краснотурьинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (475, 476, NULL, N'Красноуральск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (476, 477, NULL, N'Красноуфимск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (477, 478, NULL, N'Красноярск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (478, 479, NULL, N'Красный Кут')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (479, 480, NULL, N'Красный Сулин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (480, 481, NULL, N'Красный Холм')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (481, 482, NULL, N'Кремёнки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (482, 483, NULL, N'Кропоткин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (483, 484, NULL, N'Крымск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (484, 485, NULL, N'Кстово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (485, 486, NULL, N'Кубинка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (486, 487, NULL, N'Кувандык')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (487, 488, NULL, N'Кувшиново')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (488, 489, NULL, N'Кудрово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (489, 490, NULL, N'Кудымкар')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (490, 491, NULL, N'Кузнецк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (491, 492, NULL, N'Куйбышев')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (492, 493, NULL, N'Кукмор')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (493, 494, NULL, N'Кулебаки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (494, 495, NULL, N'Кумертау')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (495, 496, NULL, N'Кунгур')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (496, 497, NULL, N'Купино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (497, 498, NULL, N'Курган')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (498, 499, NULL, N'Курганинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (499, 500, NULL, N'Курильск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (500, 501, NULL, N'Курлово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (501, 502, NULL, N'Куровское')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (502, 503, NULL, N'Курск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (503, 504, NULL, N'Куртамыш')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (504, 505, NULL, N'Курчалой')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (505, 506, NULL, N'Курчатов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (506, 507, NULL, N'Куса')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (507, 508, NULL, N'Кушва')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (508, 509, NULL, N'Кызыл')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (509, 510, NULL, N'Кыштым')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (510, 511, NULL, N'Кяхта')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (511, 512, NULL, N'Лабинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (512, 513, NULL, N'Лабытнанги')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (513, 514, NULL, N'Лагань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (514, 515, NULL, N'Ладушкин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (515, 516, NULL, N'Лаишево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (516, 517, NULL, N'Лакинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (517, 518, NULL, N'Лангепас')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (518, 519, NULL, N'Лахденпохья')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (519, 520, NULL, N'Лебедянь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (520, 521, NULL, N'Лениногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (521, 522, NULL, N'Ленинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (522, 523, NULL, N'Ленинск-Кузнецкий')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (523, 524, NULL, N'Ленск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (524, 525, NULL, N'Лермонтов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (525, 526, NULL, N'Лесной')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (526, 527, NULL, N'Лесозаводск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (527, 528, NULL, N'Лесосибирск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (528, 529, NULL, N'Ливны')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (529, 530, NULL, N'Ликино-Дулёво')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (530, 531, NULL, N'Липецк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (531, 532, NULL, N'Липки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (532, 533, NULL, N'Лиски')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (533, 534, NULL, N'Лихославль')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (534, 535, NULL, N'Лобня')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (535, 536, NULL, N'Лодейное Поле')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (536, 537, NULL, N'Лосино-Петровский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (537, 538, NULL, N'Луга')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (538, 539, NULL, N'Луза')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (539, 540, NULL, N'Лукоянов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (540, 541, NULL, N'Луховицы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (541, 542, NULL, N'Лысково')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (542, 543, NULL, N'Лысьва')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (543, 544, NULL, N'Лыткарино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (544, 545, NULL, N'Льгов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (545, 546, NULL, N'Любань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (546, 547, NULL, N'Люберцы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (547, 548, NULL, N'Любим')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (548, 549, NULL, N'Людиново')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (549, 550, NULL, N'Лянтор')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (550, 551, NULL, N'Магадан')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (551, 552, NULL, N'Магас')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (552, 553, NULL, N'Магнитогорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (553, 554, NULL, N'Майкоп')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (554, 555, NULL, N'Майский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (555, 556, NULL, N'Макаров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (556, 557, NULL, N'Макарьев')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (557, 558, NULL, N'Макушино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (558, 559, NULL, N'Малая Вишера')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (559, 560, NULL, N'Малгобек')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (560, 561, NULL, N'Малмыж')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (561, 562, NULL, N'Малоархангельск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (562, 563, NULL, N'Малоярославец')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (563, 564, NULL, N'Мамадыш')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (564, 565, NULL, N'Мамоново')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (565, 566, NULL, N'Мантурово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (566, 567, NULL, N'Мариинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (567, 568, NULL, N'Мариинский Посад')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (568, 569, NULL, N'Маркс')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (569, 570, NULL, N'Махачкала')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (570, 571, NULL, N'Мглин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (571, 572, NULL, N'Мегион')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (572, 573, NULL, N'Медвежьегорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (573, 574, NULL, N'Медногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (574, 575, NULL, N'Медынь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (575, 576, NULL, N'Межгорье')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (576, 577, NULL, N'Междуреченск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (577, 578, NULL, N'Мезень')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (578, 579, NULL, N'Меленки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (579, 580, NULL, N'Мелеуз')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (580, 581, NULL, N'Менделеевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (581, 582, NULL, N'Мензелинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (582, 583, NULL, N'Мещовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (583, 584, NULL, N'Миасс')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (584, 585, NULL, N'Микунь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (585, 586, NULL, N'Миллерово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (586, 587, NULL, N'Минеральные Воды')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (587, 588, NULL, N'Минусинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (588, 589, NULL, N'Миньяр')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (589, 590, NULL, N'Мирный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (590, 591, NULL, N'Мирный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (591, 592, NULL, N'Михайлов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (592, 593, NULL, N'Михайловка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (593, 594, NULL, N'Михайловск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (594, 595, NULL, N'Михайловск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (595, 596, NULL, N'Мичуринск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (596, 597, NULL, N'Могоча')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (597, 598, NULL, N'Можайск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (598, 599, NULL, N'Можга')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (599, 600, NULL, N'Моздок')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (600, 601, NULL, N'Мончегорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (601, 602, NULL, N'Морозовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (602, 603, NULL, N'Моршанск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (603, 604, NULL, N'Мосальск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (604, 605, NULL, N'Москва')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (605, 606, NULL, N'Муравленко')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (606, 607, NULL, N'Мураши')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (607, 608, NULL, N'Мурино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (608, 609, NULL, N'Мурманск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (609, 610, NULL, N'Муром')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (610, 611, NULL, N'Мценск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (611, 612, NULL, N'Мыски')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (612, 613, NULL, N'Мытищи')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (613, 614, NULL, N'Мышкин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (614, 615, NULL, N'Набережные Челны')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (615, 616, NULL, N'Навашино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (616, 617, NULL, N'Наволоки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (617, 618, NULL, N'Надым')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (618, 619, NULL, N'Назарово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (619, 620, NULL, N'Назрань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (620, 621, NULL, N'Называевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (621, 622, NULL, N'Нальчик')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (622, 623, NULL, N'Нариманов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (623, 624, NULL, N'Наро-Фоминск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (624, 625, NULL, N'Нарткала')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (625, 626, NULL, N'Нарьян-Мар')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (626, 627, NULL, N'Находка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (627, 628, NULL, N'Невель')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (628, 629, NULL, N'Невельск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (629, 630, NULL, N'Невинномысск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (630, 631, NULL, N'Невьянск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (631, 632, NULL, N'Нелидово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (632, 633, NULL, N'Неман')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (633, 634, NULL, N'Нерехта')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (634, 635, NULL, N'Нерчинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (635, 636, NULL, N'Нерюнгри')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (636, 637, NULL, N'Нестеров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (637, 638, NULL, N'Нефтегорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (638, 639, NULL, N'Нефтекамск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (639, 640, NULL, N'Нефтекумск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (640, 641, NULL, N'Нефтеюганск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (641, 642, NULL, N'Нея')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (642, 643, NULL, N'Нижневартовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (643, 644, NULL, N'Нижнекамск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (644, 645, NULL, N'Нижнеудинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (645, 646, NULL, N'Нижние Серги')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (646, 647, NULL, N'Нижний Ломов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (647, 648, NULL, N'Нижний Новгород')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (648, 649, NULL, N'Нижний Тагил')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (649, 650, NULL, N'Нижняя Салда')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (650, 651, NULL, N'Нижняя Тура')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (651, 652, NULL, N'Николаевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (652, 653, NULL, N'Николаевск-на-Амуре')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (653, 654, NULL, N'Никольск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (654, 655, NULL, N'Никольск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (655, 656, NULL, N'Никольское')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (656, 657, NULL, N'Новая Ладога')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (657, 658, NULL, N'Новая Ляля')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (658, 659, NULL, N'Новоалександровск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (659, 660, NULL, N'Новоалтайск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (660, 661, NULL, N'Новоаннинский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (661, 662, NULL, N'Нововоронеж')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (662, 663, NULL, N'Новодвинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (663, 664, NULL, N'Новозыбков')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (664, 665, NULL, N'Новокубанск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (665, 666, NULL, N'Новокузнецк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (666, 667, NULL, N'Новокуйбышевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (667, 668, NULL, N'Новомичуринск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (668, 669, NULL, N'Новомосковск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (669, 670, NULL, N'Новопавловск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (670, 671, NULL, N'Новоржев')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (671, 672, NULL, N'Новороссийск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (672, 673, NULL, N'Новосибирск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (673, 674, NULL, N'Новосиль')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (674, 675, NULL, N'Новосокольники')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (675, 676, NULL, N'Новотроицк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (676, 677, NULL, N'Новоузенск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (677, 678, NULL, N'Новоульяновск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (678, 679, NULL, N'Новоуральск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (679, 680, NULL, N'Новохопёрск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (680, 681, NULL, N'Новочебоксарск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (681, 682, NULL, N'Новочеркасск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (682, 683, NULL, N'Новошахтинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (683, 684, NULL, N'Новый Оскол')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (684, 685, NULL, N'Новый Уренгой')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (685, 686, NULL, N'Ногинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (686, 687, NULL, N'Нолинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (687, 688, NULL, N'Норильск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (688, 689, NULL, N'Ноябрьск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (689, 690, NULL, N'Нурлат')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (690, 691, NULL, N'Нытва')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (691, 692, NULL, N'Нюрба')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (692, 693, NULL, N'Нягань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (693, 694, NULL, N'Нязепетровск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (694, 695, NULL, N'Няндома')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (695, 696, NULL, N'Облучье')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (696, 697, NULL, N'Обнинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (697, 698, NULL, N'Обоянь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (698, 699, NULL, N'Обь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (699, 700, NULL, N'Одинцово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (700, 701, NULL, N'Озёрск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (701, 702, NULL, N'Озёрск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (702, 703, NULL, N'Озёры')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (703, 704, NULL, N'Октябрьск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (704, 705, NULL, N'Октябрьский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (705, 706, NULL, N'Окуловка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (706, 707, NULL, N'Олёкминск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (707, 708, NULL, N'Оленегорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (708, 709, NULL, N'Олонец')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (709, 710, NULL, N'Омск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (710, 711, NULL, N'Омутнинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (711, 712, NULL, N'Онега')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (712, 713, NULL, N'Опочка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (713, 714, NULL, N'Орёл')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (714, 715, NULL, N'Оренбург')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (715, 716, NULL, N'Орехово-Зуево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (716, 717, NULL, N'Орлов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (717, 718, NULL, N'Орск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (718, 719, NULL, N'Оса')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (719, 720, NULL, N'Осинники')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (720, 721, NULL, N'Осташков')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (721, 722, NULL, N'Остров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (722, 723, NULL, N'Островной')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (723, 724, NULL, N'Острогожск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (724, 725, NULL, N'Отрадное')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (725, 726, NULL, N'Отрадный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (726, 727, NULL, N'Оха')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (727, 728, NULL, N'Оханск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (728, 729, NULL, N'Очёр')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (729, 730, NULL, N'Павлово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (730, 731, NULL, N'Павловск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (731, 732, NULL, N'Павловский Посад')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (732, 733, NULL, N'Палласовка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (733, 734, NULL, N'Партизанск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (734, 735, NULL, N'Певек')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (735, 736, NULL, N'Пенза')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (736, 737, NULL, N'Первомайск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (737, 738, NULL, N'Первоуральск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (738, 739, NULL, N'Перевоз')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (739, 740, NULL, N'Пересвет')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (740, 741, NULL, N'Переславль-Залесский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (741, 742, NULL, N'Пермь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (742, 743, NULL, N'Пестово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (743, 744, NULL, N'Петров Вал')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (744, 745, NULL, N'Петровск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (745, 746, NULL, N'Петровск-Забайкальский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (746, 747, NULL, N'Петрозаводск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (747, 748, NULL, N'Петропавловск-Камчатский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (748, 749, NULL, N'Петухово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (749, 750, NULL, N'Петушки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (750, 751, NULL, N'Печора')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (751, 752, NULL, N'Печоры')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (752, 753, NULL, N'Пикалёво')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (753, 754, NULL, N'Пионерский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (754, 755, NULL, N'Питкяранта')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (755, 756, NULL, N'Плавск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (756, 757, NULL, N'Пласт')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (757, 758, NULL, N'Плёс')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (758, 759, NULL, N'Поворино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (759, 760, NULL, N'Подольск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (760, 761, NULL, N'Подпорожье')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (761, 762, NULL, N'Покачи')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (762, 763, NULL, N'Покров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (763, 764, NULL, N'Покровск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (764, 765, NULL, N'Полевской')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (765, 766, NULL, N'Полесск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (766, 767, NULL, N'Полысаево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (767, 768, NULL, N'Полярные Зори')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (768, 769, NULL, N'Полярный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (769, 770, NULL, N'Поронайск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (770, 771, NULL, N'Порхов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (771, 772, NULL, N'Похвистнево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (772, 773, NULL, N'Почеп')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (773, 774, NULL, N'Починок')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (774, 775, NULL, N'Пошехонье')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (775, 776, NULL, N'Правдинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (776, 777, NULL, N'Приволжск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (777, 778, NULL, N'Приморск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (778, 779, NULL, N'Приморск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (779, 780, NULL, N'Приморско-Ахтарск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (780, 781, NULL, N'Приозерск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (781, 782, NULL, N'Прокопьевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (782, 783, NULL, N'Пролетарск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (783, 784, NULL, N'Протвино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (784, 785, NULL, N'Прохладный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (785, 786, NULL, N'Псков')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (786, 787, NULL, N'Пугачёв')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (787, 788, NULL, N'Пудож')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (788, 789, NULL, N'Пустошка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (789, 790, NULL, N'Пучеж')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (790, 791, NULL, N'Пушкино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (791, 792, NULL, N'Пущино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (792, 793, NULL, N'Пыталово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (793, 794, NULL, N'Пыть-Ях')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (794, 795, NULL, N'Пятигорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (795, 796, NULL, N'Радужный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (796, 797, NULL, N'Радужный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (797, 798, NULL, N'Райчихинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (798, 799, NULL, N'Раменское')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (799, 800, NULL, N'Рассказово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (800, 801, NULL, N'Ревда')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (801, 802, NULL, N'Реж')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (802, 803, NULL, N'Реутов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (803, 804, NULL, N'Ржев')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (804, 805, NULL, N'Родники')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (805, 806, NULL, N'Рославль')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (806, 807, NULL, N'Россошь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (807, 808, NULL, N'Ростов-на-Дону')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (808, 809, NULL, N'Ростов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (809, 810, NULL, N'Рошаль')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (810, 811, NULL, N'Ртищево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (811, 812, NULL, N'Рубцовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (812, 813, NULL, N'Рудня')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (813, 814, NULL, N'Руза')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (814, 815, NULL, N'Рузаевка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (815, 816, NULL, N'Рыбинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (816, 817, NULL, N'Рыбное')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (817, 818, NULL, N'Рыльск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (818, 819, NULL, N'Ряжск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (819, 820, NULL, N'Рязань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (820, 821, NULL, N'Сакине призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (821, 822, NULL, N'Салават')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (822, 823, NULL, N'Салаир')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (823, 824, NULL, N'Салехард')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (824, 825, NULL, N'Сальск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (825, 826, NULL, N'Самара')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (826, 827, NULL, N'Санкт-Петербург')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (827, 828, NULL, N'Саранск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (828, 829, NULL, N'Сарапул')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (829, 830, NULL, N'Саратов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (830, 831, NULL, N'Саров')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (831, 832, NULL, N'Сасово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (832, 833, NULL, N'Сатка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (833, 834, NULL, N'Сафоново')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (834, 835, NULL, N'Саяногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (835, 836, NULL, N'Саянск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (836, 837, NULL, N'Светлогорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (837, 838, NULL, N'Светлоград')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (838, 839, NULL, N'Светлый')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (839, 840, NULL, N'Светогорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (840, 841, NULL, N'Свирск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (841, 842, NULL, N'Свободный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (842, 843, NULL, N'Себеж')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (843, 844, NULL, N'Севастопольне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (844, 845, NULL, N'Северо-Курильск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (845, 846, NULL, N'Северобайкальск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (846, 847, NULL, N'Северодвинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (847, 848, NULL, N'Североморск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (848, 849, NULL, N'Североуральск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (849, 850, NULL, N'Северск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (850, 851, NULL, N'Севск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (851, 852, NULL, N'Сегежа')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (852, 853, NULL, N'Сельцо')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (853, 854, NULL, N'Семёнов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (854, 855, NULL, N'Семикаракорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (855, 856, NULL, N'Семилуки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (856, 857, NULL, N'Сенгилей')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (857, 858, NULL, N'Серафимович')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (858, 859, NULL, N'Сергач')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (859, 860, NULL, N'Сергиев Посад')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (860, 861, NULL, N'Сердобск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (861, 862, NULL, N'Серов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (862, 863, NULL, N'Серпухов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (863, 864, NULL, N'Сертолово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (864, 865, NULL, N'Сибай')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (865, 866, NULL, N'Сим')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (866, 867, NULL, N'Симферопольне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (867, 868, NULL, N'Сковородино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (868, 869, NULL, N'Скопин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (869, 870, NULL, N'Славгород')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (870, 871, NULL, N'Славск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (871, 872, NULL, N'Славянск-на-Кубани')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (872, 873, NULL, N'Сланцы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (873, 874, NULL, N'Слободской')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (874, 875, NULL, N'Слюдянка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (875, 876, NULL, N'Смоленск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (876, 877, NULL, N'Снежинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (877, 878, NULL, N'Снежногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (878, 879, NULL, N'Собинка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (879, 880, NULL, N'Советск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (880, 881, NULL, N'Советск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (881, 882, NULL, N'Советск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (882, 883, NULL, N'Советская Гавань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (883, 884, NULL, N'Советский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (884, 885, NULL, N'Сокол')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (885, 886, NULL, N'Солигалич')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (886, 887, NULL, N'Соликамск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (887, 888, NULL, N'Солнечногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (888, 889, NULL, N'Соль-Илецк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (889, 890, NULL, N'Сольвычегодск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (890, 891, NULL, N'Сольцы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (891, 892, NULL, N'Сорочинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (892, 893, NULL, N'Сорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (893, 894, NULL, N'Сортавала')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (894, 895, NULL, N'Сосенский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (895, 896, NULL, N'Сосновка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (896, 897, NULL, N'Сосновоборск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (897, 898, NULL, N'Сосновый Бор')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (898, 899, NULL, N'Сосногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (899, 900, NULL, N'Сочи')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (900, 901, NULL, N'Спас-Деменск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (901, 902, NULL, N'Спас-Клепики')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (902, 903, NULL, N'Спасск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (903, 904, NULL, N'Спасск-Дальний')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (904, 905, NULL, N'Спасск-Рязанский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (905, 906, NULL, N'Среднеколымск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (906, 907, NULL, N'Среднеуральск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (907, 908, NULL, N'Сретенск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (908, 909, NULL, N'Ставрополь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (909, 910, NULL, N'Старая Купавна')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (910, 911, NULL, N'Старая Русса')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (911, 912, NULL, N'Старица')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (912, 913, NULL, N'Стародуб')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (913, 914, NULL, N'Старый Крымне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (914, 915, NULL, N'Старый Оскол')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (915, 916, NULL, N'Стерлитамак')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (916, 917, NULL, N'Стрежевой')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (917, 918, NULL, N'Строитель')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (918, 919, NULL, N'Струнино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (919, 920, NULL, N'Ступино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (920, 921, NULL, N'Суворов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (921, 922, NULL, N'Судакне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (922, 923, NULL, N'Суджа')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (923, 924, NULL, N'Судогда')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (924, 925, NULL, N'Суздаль')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (925, 926, NULL, N'Сунжа')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (926, 927, NULL, N'Суоярви')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (927, 928, NULL, N'Сураж')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (928, 929, NULL, N'Сургут')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (929, 930, NULL, N'Суровикино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (930, 931, NULL, N'Сурск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (931, 932, NULL, N'Сусуман')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (932, 933, NULL, N'Сухиничи')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (933, 934, NULL, N'Сухой Лог')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (934, 935, NULL, N'Сызрань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (935, 936, NULL, N'Сыктывкар')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (936, 937, NULL, N'Сысерть')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (937, 938, NULL, N'Сычёвка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (938, 939, NULL, N'Сясьстрой')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (939, 940, NULL, N'Тавда')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (940, 941, NULL, N'Таганрог')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (941, 942, NULL, N'Тайга')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (942, 943, NULL, N'Тайшет')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (943, 944, NULL, N'Талдом')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (944, 945, NULL, N'Талица')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (945, 946, NULL, N'Тамбов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (946, 947, NULL, N'Тара')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (947, 948, NULL, N'Тарко-Сале')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (948, 949, NULL, N'Таруса')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (949, 950, NULL, N'Татарск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (950, 951, NULL, N'Таштагол')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (951, 952, NULL, N'Тверь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (952, 953, NULL, N'Теберда')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (953, 954, NULL, N'Тейково')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (954, 955, NULL, N'Темников')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (955, 956, NULL, N'Темрюк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (956, 957, NULL, N'Терек')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (957, 958, NULL, N'Тетюши')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (958, 959, NULL, N'Тимашёвск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (959, 960, NULL, N'Тихвин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (960, 961, NULL, N'Тихорецк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (961, 962, NULL, N'Тобольск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (962, 963, NULL, N'Тогучин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (963, 964, NULL, N'Тольятти')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (964, 965, NULL, N'Томари')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (965, 966, NULL, N'Томмот')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (966, 967, NULL, N'Томск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (967, 968, NULL, N'Топки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (968, 969, NULL, N'Торжок')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (969, 970, NULL, N'Торопец')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (970, 971, NULL, N'Тосно')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (971, 972, NULL, N'Тотьма')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (972, 973, NULL, N'Трёхгорный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (973, 974, NULL, N'Троицк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (974, 975, NULL, N'Трубчевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (975, 976, NULL, N'Туапсе')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (976, 977, NULL, N'Туймазы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (977, 978, NULL, N'Тула')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (978, 979, NULL, N'Тулун')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (979, 980, NULL, N'Туран')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (980, 981, NULL, N'Туринск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (981, 982, NULL, N'Тутаев')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (982, 983, NULL, N'Тында')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (983, 984, NULL, N'Тырныауз')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (984, 985, NULL, N'Тюкалинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (985, 986, NULL, N'Тюмень')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (986, 987, NULL, N'Уварово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (987, 988, NULL, N'Углегорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (988, 989, NULL, N'Углич')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (989, 990, NULL, N'Удачный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (990, 991, NULL, N'Удомля')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (991, 992, NULL, N'Ужур')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (992, 993, NULL, N'Узловая')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (993, 994, NULL, N'Улан-Удэ')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (994, 995, NULL, N'Ульяновск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (995, 996, NULL, N'Унеча')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (996, 997, NULL, N'Урай')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (997, 998, NULL, N'Урень')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (998, 999, NULL, N'Уржум')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (999, 1000, NULL, N'Урус-Мартан')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1000, 1001, NULL, N'Урюпинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1001, 1002, NULL, N'Усинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1002, 1003, NULL, N'Усмань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1003, 1004, NULL, N'Усолье-Сибирское')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1004, 1005, NULL, N'Усолье')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1005, 1006, NULL, N'Уссурийск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1006, 1007, NULL, N'Усть-Джегута')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1007, 1008, NULL, N'Усть-Илимск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1008, 1009, NULL, N'Усть-Катав')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1009, 1010, NULL, N'Усть-Кут')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1010, 1011, NULL, N'Усть-Лабинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1011, 1012, NULL, N'Устюжна')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1012, 1013, NULL, N'Уфа')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1013, 1014, NULL, N'Ухта')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1014, 1015, NULL, N'Учалы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1015, 1016, NULL, N'Уяр')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1016, 1017, NULL, N'Фатеж')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1017, 1018, NULL, N'Феодосияне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1018, 1019, NULL, N'Фокино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1019, 1020, NULL, N'Фокино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1020, 1021, NULL, N'Фролово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1021, 1022, NULL, N'Фрязино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1022, 1023, NULL, N'Фурманов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1023, 1024, NULL, N'Хабаровск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1024, 1025, NULL, N'Хадыженск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1025, 1026, NULL, N'Ханты-Мансийск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1026, 1027, NULL, N'Харабали')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1027, 1028, NULL, N'Харовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1028, 1029, NULL, N'Хасавюрт')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1029, 1030, NULL, N'Хвалынск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1030, 1031, NULL, N'Хилок')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1031, 1032, NULL, N'Химки')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1032, 1033, NULL, N'Холм')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1033, 1034, NULL, N'Холмск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1034, 1035, NULL, N'Хотьково')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1035, 1036, NULL, N'Цивильск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1036, 1037, NULL, N'Цимлянск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1037, 1038, NULL, N'Циолковский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1038, 1039, NULL, N'Чадан')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1039, 1040, NULL, N'Чайковский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1040, 1041, NULL, N'Чапаевск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1041, 1042, NULL, N'Чаплыгин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1042, 1043, NULL, N'Чебаркуль')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1043, 1044, NULL, N'Чебоксары')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1044, 1045, NULL, N'Чегем')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1045, 1046, NULL, N'Чекалин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1046, 1047, NULL, N'Челябинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1047, 1048, NULL, N'Чердынь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1048, 1049, NULL, N'Черемхово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1049, 1050, NULL, N'Черепаново')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1050, 1051, NULL, N'Череповец')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1051, 1052, NULL, N'Черкесск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1052, 1053, NULL, N'Чёрмоз')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1053, 1054, NULL, N'Черноголовка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1054, 1055, NULL, N'Черногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1055, 1056, NULL, N'Чернушка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1056, 1057, NULL, N'Черняховск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1057, 1058, NULL, N'Чехов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1058, 1059, NULL, N'Чистополь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1059, 1060, NULL, N'Чита')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1060, 1061, NULL, N'Чкаловск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1061, 1062, NULL, N'Чудово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1062, 1063, NULL, N'Чулым')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1063, 1064, NULL, N'Чусовой')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1064, 1065, NULL, N'Чухлома')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1065, 1066, NULL, N'Шагонар')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1066, 1067, NULL, N'Шадринск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1067, 1068, NULL, N'Шали')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1068, 1069, NULL, N'Шарыпово')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1069, 1070, NULL, N'Шарья')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1070, 1071, NULL, N'Шатура')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1071, 1072, NULL, N'Шахты')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1072, 1073, NULL, N'Шахунья')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1073, 1074, NULL, N'Шацк')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1074, 1075, NULL, N'Шебекино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1075, 1076, NULL, N'Шелехов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1076, 1077, NULL, N'Шенкурск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1077, 1078, NULL, N'Шилка')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1078, 1079, NULL, N'Шимановск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1079, 1080, NULL, N'Шиханы')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1080, 1081, NULL, N'Шлиссельбург')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1081, 1082, NULL, N'Шумерля')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1082, 1083, NULL, N'Шумиха')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1083, 1084, NULL, N'Шуя')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1084, 1085, NULL, N'Щёкино')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1085, 1086, NULL, N'Щёлкиноне призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1086, 1087, NULL, N'Щёлково')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1087, 1088, NULL, N'Щигры')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1088, 1089, NULL, N'Щучье')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1089, 1090, NULL, N'Электрогорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1090, 1091, NULL, N'Электросталь')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1091, 1092, NULL, N'Электроугли')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1092, 1093, NULL, N'Элиста')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1093, 1094, NULL, N'Энгельс')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1094, 1095, NULL, N'Эртиль')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1095, 1096, NULL, N'Югорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1096, 1097, NULL, N'Южа')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1097, 1098, NULL, N'Южно-Сахалинск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1098, 1099, NULL, N'Южно-Сухокумск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1099, 1100, NULL, N'Южноуральск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1100, 1101, NULL, N'Юрга')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1101, 1102, NULL, N'Юрьев-Польский')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1102, 1103, NULL, N'Юрьевец')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1103, 1104, NULL, N'Юрюзань')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1104, 1105, NULL, N'Юхнов')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1105, 1106, NULL, N'Ядрин')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1106, 1107, NULL, N'Якутск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1107, 1108, NULL, N'Ялтане призн.')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1108, 1109, NULL, N'Ялуторовск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1109, 1110, NULL, N'Янаул')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1110, 1111, NULL, N'Яранск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1111, 1112, NULL, N'Яровое')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1112, 1113, NULL, N'Ярославль')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1113, 1114, NULL, N'Ярцево')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1114, 1115, NULL, N'Ясногорск')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1115, 1116, NULL, N'Ясный')
GO
INSERT [dbo].[Города] ([Код], [Код_города], [Герб], [Наименование]) VALUES (1116, 1117, NULL, N'Яхрома')
GO
SET IDENTITY_INSERT [dbo].[Города] OFF
GO
SET IDENTITY_INSERT [dbo].[ЖюриАктивности] ON 
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (5, 1, 34)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (6, 2, 35)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (7, 3, 36)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (8, 4, 37)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (9, 5, 38)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (10, 6, 39)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (11, 7, 40)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (12, 8, 41)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (13, 9, 42)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (14, 10, 43)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (15, 11, 44)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (16, 12, 45)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (17, 13, 34)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (18, 14, 35)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (19, 15, 36)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (20, 17, 37)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (21, 18, 38)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (22, 19, 39)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (23, 20, 40)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (24, 21, 41)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (25, 22, 42)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (26, 23, 43)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (27, 24, 44)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (28, 25, 45)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (29, 26, 35)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (30, 27, 36)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (31, 28, 37)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (34, 29, 39)
GO
INSERT [dbo].[ЖюриАктивности] ([Код_жюри_активности], [Код_активности], [Код_жюри]) VALUES (35, 30, 40)
GO
SET IDENTITY_INSERT [dbo].[ЖюриАктивности] OFF
GO
SET IDENTITY_INSERT [dbo].[Мероприятия] ON 
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (3, N'Всероссийский хакатон neuromedia 2017 по разработке продуктов на стыке информационных технологий, медиа и нейронных сетей ', CAST(N'2022-10-26' AS Date), 1, 34, 2)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (4, N'Встреча #3 клуба ITBizRadio на тему:  «уборка» — выкидываем ненужные навыки, инструменты и ограничения» ', CAST(N'2022-07-14' AS Date), 3, 34, 2)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (5, N'Встреча клуба «Leader stories»: Мотивирующее руководство ', CAST(N'2023-11-09' AS Date), 2, 2, 5)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (6, N'Встреча клуба руководителей «Leader Stories»: Постановка целей команде ', CAST(N'2023-07-06' AS Date), 2, 66, 5)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (7, N'Быстрее, выше, сильнее: как спорт помогает бизнесу и корпорациям ', CAST(N'2023-04-13' AS Date), 3, 4, 5)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (8, N'Встреча клуба Leader Stories «Мотивирующее руководство» ', CAST(N'2022-02-20' AS Date), 3, 76, 5)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (9, N'Встреча клуба Leader Stories в формате настольной трансформационной коучинговой игры «УниверсУм» ', CAST(N'2023-10-10' AS Date), 2, 78, 5)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (10, N'Встреча пользователей PTV в России ', CAST(N'2022-04-16' AS Date), 3, 50, 2)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (11, N'Встреча сообщества CocoaHeads Russia ', CAST(N'2023-07-01' AS Date), 3, 78, 2)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (12, N'Встреча СПб СоА 16 апреля. Репетиция докладов к Analyst Days ', CAST(N'2022-10-18' AS Date), 1, 78, 3)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (13, N'Встреча JUG.ru с Венкатом Субраманиамом — Design Patterns in the Light of Lambda Expressions ', CAST(N'2023-08-26' AS Date), 1, 56, 4)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (14, N'Встреча №3 HR-клуба Моего круга ', CAST(N'2022-11-27' AS Date), 1, 45, 5)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (15, N'Встреча №4 HR-клуба «Моего круга» ', CAST(N'2023-10-31' AS Date), 2, 78, 6)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (16, N'Встреча SPb Python Community ', CAST(N'2022-07-02' AS Date), 3, 9, 2)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (17, N'Встреча SpbDotNet №36 ', CAST(N'2022-10-14' AS Date), 3, 8, 2)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (18, N'Встреча SpbDotNet №40 ', CAST(N'2023-05-08' AS Date), 2, 23, 2)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (19, N'Встреча SpbDotNet №44 ', CAST(N'2022-05-10' AS Date), 2, 56, 2)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (20, N'Вторая международная конференция и выставка «ЦОД: модели, сервисы, инфраструктура - 2018» ', CAST(N'2022-03-03' AS Date), 2, 33, 2)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (21, N'Выбор и создание методов решения аналитических задач ', CAST(N'2023-09-13' AS Date), 2, 22, 5)
GO
INSERT [dbo].[Мероприятия] ([Код_мероприятия], [Событие], [Дата_проведения], [Дни], [Код_города_проведения], [Код_направления]) VALUES (22, N'Выгорание: от бесплатного печенья до депрессии ', CAST(N'2023-11-11' AS Date), 3, 4, 5)
GO
SET IDENTITY_INSERT [dbo].[Мероприятия] OFF
GO
SET IDENTITY_INSERT [dbo].[МодераторыМероприятия] ON 
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (1, 1, 8)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (2, 2, 8)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (3, 3, 8)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (4, 4, 7)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (5, 5, 7)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (6, 6, 7)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (7, 7, 10)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (8, 8, 10)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (9, 9, 10)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (10, 10, 12)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (11, 11, 12)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (12, 12, 12)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (13, 13, 14)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (14, 14, 14)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (15, 15, 14)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (16, 16, 15)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (17, 17, 15)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (18, 18, 15)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (19, 19, 21)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (20, 20, 21)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (21, 21, 21)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (23, 24, 3)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (1003, 1004, 11)
GO
INSERT [dbo].[МодераторыМероприятия] ([Код_модератора_мероприятия], [Код_модератора], [Код_мероприятия]) VALUES (2002, 2002, 3)
GO
SET IDENTITY_INSERT [dbo].[МодераторыМероприятия] OFF
GO
SET IDENTITY_INSERT [dbo].[Направления] ON 
GO
INSERT [dbo].[Направления] ([Код_направления], [Направление]) VALUES (2, N'ИТ')
GO
INSERT [dbo].[Направления] ([Код_направления], [Направление]) VALUES (3, N'Биг Дата')
GO
INSERT [dbo].[Направления] ([Код_направления], [Направление]) VALUES (4, N'Дизайн')
GO
INSERT [dbo].[Направления] ([Код_направления], [Направление]) VALUES (5, N'Аналитика')
GO
INSERT [dbo].[Направления] ([Код_направления], [Направление]) VALUES (6, N'Информационная безопасность')
GO
SET IDENTITY_INSERT [dbo].[Направления] OFF
GO
SET IDENTITY_INSERT [dbo].[Пользователи] ON 
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (1, N'Васильев Всеволод Давидович', N'мужской', N'6z92wongmash@tutanota.com', CAST(N'1988-10-16' AS Date), 51, N'7(354)903-53-67', NULL, N'Ke22Yh8Pp7', N'foto1.jpg', 1)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (2, N'Новиков Фёдор Макарович', N'мужской', N'jkp23vlzsqei@gmail.com', CAST(N'1980-08-03' AS Date), 33, N'7(6562)925-01-77', NULL, N'Tj78jXeH68', N'foto2.jpg', 1)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (3, N'Фролова Владислава Савельевна', N'женский', N'dncmxp1vqr4t@tutanota.com', CAST(N'1999-07-13' AS Date), 43, N'7(12)981-33-56', NULL, N'DF9a8cJf82', N'foto3.jpg', 1)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (4, N'Кузнецов Елисей Александрович', N'мужской', N'sn4xvg8wyb0h@outlook.com', CAST(N'1983-12-19' AS Date), 3, N'7(698)667-22-45', NULL, N'B2bdk8FD27', N'foto4.jpg', 1)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (5, N'Рябова София Матвеевна', N'женский', N'9zaecohlw2xy@tutanota.com', CAST(N'1998-08-10' AS Date), 33, N'7(38)393-11-43', NULL, N'58vMHdK4g5', N'foto5.jpg', 1)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (6, N'Власов Арсений Львович', N'мужской', N'sohzld6c52mv@gmail.com', CAST(N'1980-05-28' AS Date), 31, N'7(4297)539-13-81', NULL, N'T3uhc34E9Z', N'foto6.jpg', 1)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (7, N'Маслова Екатерина Макаровна', N'женский', N'a1v0lgxsz3qb@mail.com', CAST(N'1983-10-26' AS Date), 40, N'7(49)638-66-62', NULL, N'dj8PN3b4M9', N'foto7.jpg', 1)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (8, N'Агафонов Давид Артёмович', N'мужской', N'lry2ko5t031w@gmail.com', CAST(N'1995-10-14' AS Date), 27, N'7(65)706-55-85', NULL, N'uy69Pp8DY6', N'foto8.jpg', 1)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (9, N'Федотова Варвара Сергеевна', N'женский', N'omrjzf0pc8n6@outlook.com', CAST(N'1996-12-05' AS Date), 2, N'7(40)420-24-06', NULL, N'Sp3k6Ax86E', N'foto9.jpg', 1)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (10, N'Кудряшова Виктория Дмитриевна', N'женский', N't1wpou7merxi@yahoo.com', CAST(N'1999-02-13' AS Date), 16, N'7(427)939-24-67', NULL, N'fvm774FV3R', N'foto10.jpg', 1)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (11, N'Царева Виктория Давидовна', N'женский', N'iunhxq41tgr5@tutanota.com', CAST(N'1988-07-03' AS Date), 33, N'7(567)103-73-32', 2, N'FYi396Dd5u', N'foto9.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (12, N'Зорин Дмитрий Маркович', N'мужской', N'ofdt4z1bijq0@tutanota.com', CAST(N'1993-09-07' AS Date), 57, N'7(79)644-01-06', 2, N'7gi7E8K4Ng', N'foto10.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (13, N'Зотова Анна Тимуровна', N'женский', N'ac6yxzg7rl5k@mail.com', CAST(N'1990-09-21' AS Date), 11, N'7(488)643-19-98', 3, N'3L3eA5eEg3', N'foto8.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (14, N'Соловьев Тимур Константинович', N'мужской', N'b1p4ur8nsedj@yahoo.com', CAST(N'1992-09-03' AS Date), 45, N'7(1828)504-39-49', 4, N'Si8S5kS83v', N'foto11.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (15, N'Малахов Александр Фёдорович', N'мужской', N'wyo6k9emv1j5@mail.com', CAST(N'1957-05-18' AS Date), 78, N'7(905)793-68-23', 3, N'T83vfX2Z3b', N'foto12.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (16, N'Зорин Марк Ярославович', N'мужской', N'g7kwp8lu65xi@tutanota.com', CAST(N'1961-03-09' AS Date), 82, N'7(54)522-60-54', 5, N'25cPn58HxV', N'foto13.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (17, N'Егорова Ева Михайловна', N'женский', N'doj5r1m8xnky@gmail.com', CAST(N'1987-06-15' AS Date), 80, N'7(05)441-48-14', 2, N'3z86YDzaX8', N'foto14.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (18, N'Гущина Кристина Львовна', N'женский', N'bxk06h5touyr@mail.com', CAST(N'1966-06-28' AS Date), 47, N'7(023)826-25-26', 6, N't8F9hZXp89', N'foto16.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (19, N'Кудрявцева Виктория Романовна', N'женский', N'26yf8xbcntgp@gmail.com', CAST(N'1953-01-27' AS Date), 30, N'7(7804)582-64-90', 3, N'92mARR3gu4', N'foto17.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (20, N'Новикова Александра Александровна', N'женский', N'0z4fvq65c7tg@gmail.com', CAST(N'1982-09-02' AS Date), 76, N'7(1472)122-56-07', 5, N'Kf64Y6rhZ3', N'foto18.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (21, N'Масленников Родион Филиппович', N'мужской', N'3kma18t5furi@gmail.com', CAST(N'1952-06-09' AS Date), 24, N'7(23)912-71-67', 5, N's7iAYE9d38', N'foto19.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (22, N'Иванов Тимур Иванович', N'мужской', N'ws7nxyhd6g1o@yahoo.com', CAST(N'1955-08-30' AS Date), 6, N'7(5939)489-85-18', 6, N'3Ga9jfT9D2', N'foto20.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (23, N'Иванов Сергей Степанович', N'мужской', N'oitzvs1mylj2@gmail.com', CAST(N'1993-09-01' AS Date), 83, N'7(4020)034-48-35', 4, N'N6598CFsgi', N'foto21.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (24, N'Спиридонов Ярослав Сергеевич', N'мужской', N'las6pufjkv45@outlook.com', CAST(N'1969-04-22' AS Date), 64, N'7(17)843-77-26', 4, N'DV5625Zfmj', N'foto22.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (25, N'Виноградова Эмилия Валерьевна', N'женский', N'nl81b9i7s0ka@gmail.com', CAST(N'1991-10-25' AS Date), 90, N'7(16)788-42-97', 4, N'22YyD83dMg', N'foto23.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (26, N'Мартынова Ева Семёновна', N'женский', N'ma87ser3gkj9@yahoo.com', CAST(N'1984-03-24' AS Date), 54, N'7(087)267-87-85', 6, N'522EmkEmA6', N'foto24.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (27, N'Яковлева Анисия Григорьевна', N'женский', N'dfmygtwpecj9@tutanota.com', CAST(N'1997-09-13' AS Date), 53, N'7(798)711-92-89', 6, N'uf9u227NYU', N'foto25.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (28, N'Свиридов Тимофей Александрович', N'мужской', N'82zju4yritwo@mail.com', CAST(N'1991-07-22' AS Date), 84, N'7(68)882-28-10', 3, N'4UDk9p76mD', N'foto26.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (29, N'Медведев Захар Даниилович', N'мужской', N'zo6nye42s87t@yahoo.com', CAST(N'1960-04-11' AS Date), 63, N'7(36)230-79-77', 5, N'cK49u3JU4n', N'foto27.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (30, N'Тихонова Елизавета Александровна', N'женский', N'0cejwmnpqtb6@gmail.com', CAST(N'1955-01-07' AS Date), 34, N'7(2594)224-28-37', 6, N'b2JHb32S8i', N'foto28.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (31, N'Рыжов Роман Константинович', N'мужской', N'42thql96cwe5@yahoo.com', CAST(N'1981-12-30' AS Date), 67, N'7(1009)025-64-70', 3, N'uASc9446eF', N'foto29.jpg', 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (32, N'eddsdsd', N'женский', N'dadad.ss@ss.su', NULL, 1, N'3918398', 3, N'123', NULL, 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (33, N'Архипов Виталий Иванович', N'мужской', N'vitalya.kent@yandex.ru', NULL, 185, N'+7(908)115-60-60', 6, N'tester123', NULL, 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (34, N'Галкина Верона Васильевна', N'женский', N'obuckridge@sipes.com', CAST(N'1966-05-12' AS Date), 35, N'7(880)544-61-83', 4, N'HHikbP', N'foto21.jpg', 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (35, N'Герасимова Айлин Ефимовна', N'женский', N'loraine.aufderhar@johnston.info', CAST(N'1966-06-09' AS Date), 53, N'7(835)478-61-60', 4, N'TuhRzy', N'foto22.jpg', 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (36, N'Большаков Августин Алексеевич', N'мужской', N'juanita.kuvalis@yahoo.com', CAST(N'1978-07-12' AS Date), 52, N'7(173)770-55-13', 2, N'4Y83lz', N'foto23.jpg', 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (37, N'Морозов Ким Демьянович', N'мужской', N'ibode@lebsack.com', CAST(N'1981-10-11' AS Date), 67, N'7(518)761-85-69', 2, N'z0q7Co', N'foto24.jpg', 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (38, N'Кошелев Лука Артёмович', N'мужской', N'lilly.rodriguez@yahoo.com', NULL, 81, N'7(375)644-35-80', 2, N'uB8I2Z', N'foto25.jpg', 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (39, N'Ларионова Марина Владимировна', N'женский', N'sandrine84@gmail.com', CAST(N'1950-06-06' AS Date), 94, N'7(521)121-28-90', 2, N'o7Cjwu', N'foto26.jpg', 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (40, N'Маслова Марфа Феликсовна', N'женский', N'pearlie.watsica@wintheiser.com', NULL, 52, N'7(615)741-11-77', 3, N'zC4bi7', N'foto27.jpg', 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (41, N'Гришин Вениамин Петрович', N'мужской', N'kaela97@hotmail.com', NULL, 72, N'7(420)788-04-09', 6, N'ubeQbm', N'foto28.jpg', 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (42, N'Гришин Владислав Аркадьевич', N'мужской', N'gino.baumbach@gmail.com', NULL, 34, N'7(207)088-79-39', 2, N'16BLjl', N'foto29.jpg', 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (43, N'Корнилова Габи Георгьевна', N'женский', N'deja76@mante.info', NULL, 64, N'7(809)651-85-96', 6, N'XLleqI', N'foto30.jpg', 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (44, N'Зубенко Михаил Петрович', N'мужской', N'mafioznik777@yandex.ru', NULL, 1, N'+7(999)-123-12-23', 6, N'qwerty123', NULL, 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (45, N'Ffff fff fff', N'мужской', N'ffff@dff.rk', NULL, 1, N'131131231', 2, N'1234', NULL, 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (67, N'Ершова Нора Федотовна', N'женский', N'techie@outlook.com', CAST(N'1987-03-26' AS Date), 71, N'9.60424e+009', NULL, N'tKKevv8%', N'foto60.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (68, N'Афанасьева Жанна Валентиновна', N'женский', N'agapow@yahoo.com', CAST(N'1988-01-04' AS Date), 34, N'9.30662e+009', NULL, N'huSfHm4$', N'foto61.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (69, N'Крылова Рая Всеволодовна', N'женский', N'chaikin@yahoo.ca', CAST(N'1988-04-05' AS Date), 73, N'9.57266e+009', NULL, N'TlUwMw77%', N'foto62.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (70, N'Попова Вида Тимофеевна', N'женский', N'lbecchi@yahoo.ca', CAST(N'1989-10-25' AS Date), 64, N'9.11744e+009', NULL, N'%afF#@6', N'foto63.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (71, N'Давыдова Сандра Богуславовна', N'женский', N'bbirth@gmail.com', CAST(N'1989-12-27' AS Date), 55, N'9.84878e+009', NULL, N'SU4Jpw"', N'foto64.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (72, N'Прохорова Сабина Созоновна', N'женский', N'library@sbcglobal.net', CAST(N'1990-01-16' AS Date), 77, N'9.405e+009', NULL, N'wL#O0V', N'foto65.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (73, N'Громова Сильва Адольфовна', N'женский', N'sisyphus@live.com', CAST(N'1990-06-13' AS Date), 52, N'9.56057e+009', NULL, N'p5r{zY', N'foto66.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (74, N'Боброва Джема Феликсовна', N'женский', N'msroth@hotmail.com', CAST(N'1990-07-03' AS Date), 28, N'9.65493e+009', NULL, N'wTVK~M1', N'foto67.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (75, N'Фокина Алия Юлиановна', N'женский', N'dodong@yahoo.com', CAST(N'1990-11-27' AS Date), 53, N'9.9733e+009', NULL, N'8*Zfaj', N'foto68.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (76, N'Калинина Маргарита Анатольевна', N'женский', N'bcevc@hotmail.com', CAST(N'1991-06-08' AS Date), 74, N'9.64572e+009', NULL, N'4sBGr*', N'foto69.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (77, N'Горшкова Дина Тарасовна', N'женский', N'sethbrown@aol.com', CAST(N'1991-08-13' AS Date), 7, N'9.18419e+009', NULL, N'BpC8e8]', N'foto70.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (78, N'Гуляева Ирэна Юрьевна', N'женский', N'ftgvh2xbdaps@tutanota.com', CAST(N'1992-10-03' AS Date), 38, N'9.18414e+008', NULL, N'cI1CTd', N'foto1.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (79, N'Бурова Келен Натановна', N'женский', N'ervbd91pfcoi@mail.com', NULL, 54, N'9.18418e+009', NULL, N'MPmfYk', N'foto2.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (80, N'Королёва Лаура Пётровна', N'женский', N'p3y4b981xwdl@outlook.com', NULL, 24, N'9.18419e+010', NULL, N'omtSW3', N'foto3.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (81, N'Степанова Розалия Евсеевна', N'женский', N'8e9kvxq6z70o@mail.com', CAST(N'1994-11-02' AS Date), 24, N'9.18418e+009', NULL, N'cErGgC', N'foto4.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (82, N'Тимофеева Евгения Викторовна', N'женский', N'obnk82vzpg34@yahoo.com', CAST(N'1982-01-02' AS Date), 11, N'9.18418e+009', NULL, N'q2se3v', N'foto5.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (83, N'Дроздова Винетта Германовна', N'женский', N'wl652rgtk9js@gmail.com', NULL, 1, N'9.18418e+009', NULL, N'KnqfAk', N'foto6.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (84, N'Лукина Ксения Романовна', N'женский', N'23rgct5v1myx@gmail.com', NULL, 2, N'9.18418e+009', NULL, N'6YxPwE', N'foto7.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (85, N'Мышкина Триана Геннадьевна', N'женский', N'i4fs8e6mlk5p@yahoo.com', NULL, 54, N'9.18419e+009', NULL, N'pBQpPx', N'foto8.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (86, N'Михеева Аделия Авксентьевна', N'женский', N'4hu6f8dxvngq@tutanota.com', CAST(N'1989-06-11' AS Date), 64, N'9.18239e+009', NULL, N'FkX6Ms', N'foto9.jpg', 4)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (1002, N'Павлов Павел Иванович', N'мужской', N'pasha123@lol.kek', NULL, 9, N'79081112247', 2, N'pasha123', NULL, 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (1003, N'Test Test Test', N'мужской', N'test@test.ru', NULL, 185, N'84783478374', 6, N'test111', NULL, 3)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (1004, N'Try Try Try', N'женский', N'try@try.ru', NULL, 12, N'1314243232', 5, N'try000', NULL, 2)
GO
INSERT [dbo].[Пользователи] ([Код_пользователя], [ФИО], [Пол], [Почта], [Дата_рождения], [Код_страны], [Телефон], [Код_направления], [Пароль], [Фото], [Код_роли]) VALUES (2002, N'Зубенко Кирилл Сергеевич', N'мужской', N'fhjfh@yandex.ru', NULL, 1, N'79087786745', 2, N'test123', NULL, 2)
GO
SET IDENTITY_INSERT [dbo].[Пользователи] OFF
GO
SET IDENTITY_INSERT [dbo].[Роли] ON 
GO
INSERT [dbo].[Роли] ([Код_роли], [Наименование]) VALUES (1, N'Организатор')
GO
INSERT [dbo].[Роли] ([Код_роли], [Наименование]) VALUES (2, N'Модератор')
GO
INSERT [dbo].[Роли] ([Код_роли], [Наименование]) VALUES (3, N'Жюри')
GO
INSERT [dbo].[Роли] ([Код_роли], [Наименование]) VALUES (4, N'Участник')
GO
SET IDENTITY_INSERT [dbo].[Роли] OFF
GO
SET IDENTITY_INSERT [dbo].[Страны] ON 
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (1, 4, N'Афганистан', N'Afghanistan', N'AF')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (2, 8, N'Албания', N'Albania', N'AL')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (3, 10, N'Антарктида', N'Antarctica', N'AQ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (4, 12, N'Алжир', N'Algeria', N'DZ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (5, 16, N'Американское Самоа', N'American Samoa', N'AS')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (6, 20, N'Андорра', N'Andorra', N'AD')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (7, 24, N'Ангола', N'Angola', N'AO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (8, 28, N'Антигуа и Барбуда', N'Antigua and Barbuda', N'AG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (9, 31, N'Азербайджан', N'Azerbaijan', N'AZ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (10, 32, N'Аргентина', N'Argentina', N'AR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (11, 36, N'Австралия', N'Australia', N'AU')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (12, 40, N'Австрия', N'Austria', N'AT')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (13, 44, N'Багамы', N'Bahamas', N'BS')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (14, 48, N'Бахрейн', N'Bahrain', N'BH')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (15, 50, N'Бангладеш', N'Bangladesh', N'BD')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (16, 51, N'Армения', N'Armenia', N'AM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (17, 52, N'Барбадос', N'Barbados', N'BB')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (18, 56, N'Бельгия', N'Belgium', N'BE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (19, 60, N'Бермуды', N'Bermuda', N'BM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (20, 64, N'Бутан', N'Bhutan', N'BT')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (21, 68, N'Боливия, Многонациональное Государство', N'Bolivia, plurinational state of', N'BO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (22, 70, N'Босния и Герцеговина', N'Bosnia and Herzegovina', N'BA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (23, 72, N'Ботсвана', N'Botswana', N'BW')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (24, 74, N'Остров Буве', N'Bouvet Island', N'BV')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (25, 76, N'Бразилия', N'Brazil', N'BR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (26, 84, N'Белиз', N'Belize', N'BZ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (27, 86, N'Британская территория в Индийском океане', N'British Indian Ocean Territory', N'IO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (28, 90, N'Соломоновы острова', N'Solomon Islands', N'SB')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (29, 92, N'Виргинские острова, Британские', N'Virgin Islands, British', N'VG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (30, 96, N'Бруней-Даруссалам', N'Brunei Darussalam', N'BN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (31, 100, N'Болгария', N'Bulgaria', N'BG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (32, 104, N'Мьянма', N'Myanmar', N'MM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (33, 108, N'Бурунди', N'Burundi', N'BI')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (34, 112, N'Беларусь', N'Belarus', N'BY')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (35, 116, N'Камбоджа', N'Cambodia', N'KH')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (36, 120, N'Камерун', N'Cameroon', N'CM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (37, 124, N'Канада', N'Canada', N'CA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (38, 132, N'Кабо-Верде', N'Cape Verde', N'CV')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (39, 136, N'Острова Кайман', N'Cayman Islands', N'KY')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (40, 140, N'Центрально-Африканская Республика', N'Central African Republic', N'CF')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (41, 144, N'Шри-Ланка', N'Sri Lanka', N'LK')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (42, 148, N'Чад', N'Chad', N'TD')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (43, 152, N'Чили', N'Chile', N'CL')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (44, 156, N'Китай', N'China', N'CN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (45, 158, N'Тайвань (Китай)', N'Taiwan, Province of China', N'TW')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (46, 162, N'Остров Рождества', N'Christmas Island', N'CX')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (47, 166, N'Кокосовые (Килинг) острова', N'Cocos (Keeling) Islands', N'CC')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (48, 170, N'Колумбия', N'Colombia', N'CO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (49, 174, N'Коморы', N'Comoros', N'KM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (50, 175, N'Майотта', N'Mayotte', N'YT')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (51, 178, N'Конго', N'Congo', N'CG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (52, 180, N'Конго, Демократическая Республика', N'Congo, Democratic Republic of the', N'CD')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (53, 184, N'Острова Кука', N'Cook Islands', N'CK')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (54, 188, N'Коста-Рика', N'Costa Rica', N'CR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (55, 191, N'Хорватия', N'Croatia', N'HR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (56, 192, N'Куба', N'Cuba', N'CU')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (57, 196, N'Кипр', N'Cyprus', N'CY')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (58, 203, N'Чешская Республика', N'Czech Republic', N'CZ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (59, 204, N'Бенин', N'Benin', N'BJ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (60, 208, N'Дания', N'Denmark', N'DK')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (61, 212, N'Доминика', N'Dominica', N'DM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (62, 214, N'Доминиканская Республика', N'Dominican Republic', N'DO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (63, 218, N'Эквадор', N'Ecuador', N'EC')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (64, 222, N'Эль-Сальвадор', N'El Salvador', N'SV')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (65, 226, N'Экваториальная Гвинея', N'Equatorial Guinea', N'GQ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (66, 231, N'Эфиопия', N'Ethiopia', N'ET')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (67, 232, N'Эритрея', N'Eritrea', N'ER')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (68, 233, N'Эстония', N'Estonia', N'EE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (69, 234, N'Фарерские острова', N'Faroe Islands', N'FO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (70, 238, N'Фолклендские острова (Мальвинские)', N'Falkland Islands (Malvinas)', N'FK')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (71, 239, N'Южная Джорджия и Южные Сандвичевы острова', N'South Georgia and the South Sandwich Islands', N'GS')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (72, 242, N'Фиджи', N'Fiji', N'FJ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (73, 246, N'Финляндия', N'Finland', N'FI')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (74, 248, N'Эландские острова', N'Åland Islands', N'AX')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (75, 250, N'Франция', N'France', N'FR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (76, 254, N'Французская Гвиана', N'French Guiana', N'GF')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (77, 258, N'Французская Полинезия', N'French Polynesia', N'PF')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (78, 260, N'Французские Южные территории', N'French Southern Territories', N'TF')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (79, 262, N'Джибути', N'Djibouti', N'DJ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (80, 266, N'Габон', N'Gabon', N'GA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (81, 268, N'Грузия', N'Georgia', N'GE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (82, 270, N'Гамбия', N'Gambia', N'GM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (83, 275, N'Палестинская территория, оккупированная', N'Palestinian Territory, Occupied', N'PS')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (84, 276, N'Германия', N'Germany', N'DE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (85, 288, N'Гана', N'Ghana', N'GH')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (86, 292, N'Гибралтар', N'Gibraltar', N'GI')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (87, 296, N'Кирибати', N'Kiribati', N'KI')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (88, 300, N'Греция', N'Greece', N'GR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (89, 304, N'Гренландия', N'Greenland', N'GL')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (90, 308, N'Гренада', N'Grenada', N'GD')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (91, 312, N'Гваделупа', N'Guadeloupe', N'GP')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (92, 316, N'Гуам', N'Guam', N'GU')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (93, 320, N'Гватемала', N'Guatemala', N'GT')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (94, 324, N'Гвинея', N'Guinea', N'GN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (95, 328, N'Гайана', N'Guyana', N'GY')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (96, 332, N'Гаити', N'Haiti', N'HT')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (97, 334, N'Остров Херд и острова Макдональд', N'Heard Island and McDonald Islands', N'HM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (98, 336, N'Папский Престол (Государство — город Ватикан)', N'Holy See (Vatican City State)', N'VA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (99, 340, N'Гондурас', N'Honduras', N'HN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (100, 344, N'Гонконг', N'Hong Kong', N'HK')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (101, 348, N'Венгрия', N'Hungary', N'HU')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (102, 352, N'Исландия', N'Iceland', N'IS')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (103, 356, N'Индия', N'India', N'IN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (104, 360, N'Индонезия', N'Indonesia', N'ID')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (105, 364, N'Иран, Исламская Республика', N'Iran, Islamic Republic of', N'IR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (106, 368, N'Ирак', N'Iraq', N'IQ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (107, 372, N'Ирландия', N'Ireland', N'IE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (108, 376, N'Израиль', N'Israel', N'IL')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (109, 380, N'Италия', N'Italy', N'IT')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (110, 384, N'Кот д''Ивуар', N'Cote d''Ivoire', N'CI')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (111, 388, N'Ямайка', N'Jamaica', N'JM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (112, 392, N'Япония', N'Japan', N'JP')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (113, 398, N'Казахстан', N'Kazakhstan', N'KZ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (114, 400, N'Иордания', N'Jordan', N'JO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (115, 404, N'Кения', N'Kenya', N'KE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (116, 408, N'Корея, Народно-Демократическая Республика', N'Korea, Democratic People''s republic of', N'KP')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (117, 410, N'Корея, Республика', N'Korea, Republic of', N'KR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (118, 414, N'Кувейт', N'Kuwait', N'KW')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (119, 417, N'Киргизия', N'Kyrgyzstan', N'KG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (120, 418, N'Лаос', N'Lao People''s Democratic Republic', N'LA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (121, 422, N'Ливан', N'Lebanon', N'LB')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (122, 426, N'Лесото', N'Lesotho', N'LS')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (123, 428, N'Латвия', N'Latvia', N'LV')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (124, 430, N'Либерия', N'Liberia', N'LR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (125, 434, N'Ливийская Арабская Джамахирия', N'Libyan Arab Jamahiriya', N'LY')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (126, 438, N'Лихтенштейн', N'Liechtenstein', N'LI')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (127, 440, N'Литва', N'Lithuania', N'LT')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (128, 442, N'Люксембург', N'Luxembourg', N'LU')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (129, 446, N'Макао', N'Macao', N'MO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (130, 450, N'Мадагаскар', N'Madagascar', N'MG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (131, 454, N'Малави', N'Malawi', N'MW')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (132, 458, N'Малайзия', N'Malaysia', N'MY')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (133, 462, N'Мальдивы', N'Maldives', N'MV')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (134, 466, N'Мали', N'Mali', N'ML')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (135, 470, N'Мальта', N'Malta', N'MT')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (136, 474, N'Мартиника', N'Martinique', N'MQ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (137, 478, N'Мавритания', N'Mauritania', N'MR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (138, 480, N'Маврикий', N'Mauritius', N'MU')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (139, 484, N'Мексика', N'Mexico', N'MX')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (140, 492, N'Монако', N'Monaco', N'MC')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (141, 496, N'Монголия', N'Mongolia', N'MN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (142, 498, N'Молдова, Республика', N'Moldova', N'MD')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (143, 499, N'Черногория', N'Montenegro', N'ME')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (144, 500, N'Монтсеррат', N'Montserrat', N'MS')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (145, 504, N'Марокко', N'Morocco', N'MA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (146, 508, N'Мозамбик', N'Mozambique', N'MZ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (147, 512, N'Оман', N'Oman', N'OM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (148, 516, N'Намибия', N'Namibia', N'NA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (149, 520, N'Науру', N'Nauru', N'NR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (150, 524, N'Непал', N'Nepal', N'NP')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (151, 528, N'Нидерланды', N'Netherlands', N'NL')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (152, 531, N'Кюрасао', N'Curaçao', N'CW')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (153, 533, N'Аруба', N'Aruba', N'AW')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (154, 534, N'Синт-Мартен', N'Sint Maarten', N'SX')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (155, 535, N'Бонайре, Саба и Синт-Эстатиус', N'Bonaire, Sint Eustatius and Saba', N'BQ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (156, 540, N'Новая Каледония', N'New Caledonia', N'NC')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (157, 548, N'Вануату', N'Vanuatu', N'VU')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (158, 554, N'Новая Зеландия', N'New Zealand', N'NZ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (159, 558, N'Никарагуа', N'Nicaragua', N'NI')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (160, 562, N'Нигер', N'Niger', N'NE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (161, 566, N'Нигерия', N'Nigeria', N'NG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (162, 570, N'Ниуэ', N'Niue', N'NU')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (163, 574, N'Остров Норфолк', N'Norfolk Island', N'NF')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (164, 578, N'Норвегия', N'Norway', N'NO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (165, 580, N'Северные Марианские острова', N'Northern Mariana Islands', N'MP')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (166, 581, N'Малые Тихоокеанские отдаленные острова Соединенных Штатов', N'United States Minor Outlying Islands', N'UM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (167, 583, N'Микронезия, Федеративные Штаты', N'Micronesia, Federated States of', N'FM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (168, 584, N'Маршалловы острова', N'Marshall Islands', N'MH')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (169, 585, N'Палау', N'Palau', N'PW')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (170, 586, N'Пакистан', N'Pakistan', N'PK')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (171, 591, N'Панама', N'Panama', N'PA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (172, 598, N'Папуа-Новая Гвинея', N'Papua New Guinea', N'PG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (173, 600, N'Парагвай', N'Paraguay', N'PY')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (174, 604, N'Перу', N'Peru', N'PE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (175, 608, N'Филиппины', N'Philippines', N'PH')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (176, 612, N'Питкерн', N'Pitcairn', N'PN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (177, 616, N'Польша', N'Poland', N'PL')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (178, 620, N'Португалия', N'Portugal', N'PT')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (179, 624, N'Гвинея-Бисау', N'Guinea-Bissau', N'GW')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (180, 626, N'Тимор-Лесте', N'Timor-Leste', N'TL')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (181, 630, N'Пуэрто-Рико', N'Puerto Rico', N'PR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (182, 634, N'Катар', N'Qatar', N'QA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (183, 638, N'Реюньон', N'Reunion', N'RE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (184, 642, N'Румыния', N'Romania', N'RO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (185, 643, N'Россия', N'Russian Federation', N'RU')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (186, 646, N'Руанда', N'Rwanda', N'RW')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (187, 652, N'Сен-Бартельми', N'Saint Barthélemy', N'BL')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (188, 654, N'Святая Елена, Остров вознесения, Тристан-да-Кунья', N'Saint Helena, Ascension And Tristan Da Cunha', N'SH')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (189, 659, N'Сент-Китс и Невис', N'Saint Kitts and Nevis', N'KN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (190, 660, N'Ангилья', N'Anguilla', N'AI')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (191, 662, N'Сент-Люсия', N'Saint Lucia', N'LC')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (192, 663, N'Сен-Мартен', N'Saint Martin (French Part)', N'MF')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (193, 666, N'Сент-Пьер и Микелон', N'Saint Pierre and Miquelon', N'PM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (194, 670, N'Сент-Винсент и Гренадины', N'Saint Vincent and the Grenadines', N'VC')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (195, 674, N'Сан-Марино', N'San Marino', N'SM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (196, 678, N'Сан-Томе и Принсипи', N'Sao Tome and Principe', N'ST')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (197, 682, N'Саудовская Аравия', N'Saudi Arabia', N'SA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (198, 686, N'Сенегал', N'Senegal', N'SN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (199, 688, N'Сербия', N'Serbia', N'RS')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (200, 690, N'Сейшелы', N'Seychelles', N'SC')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (201, 694, N'Сьерра-Леоне', N'Sierra Leone', N'SL')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (202, 702, N'Сингапур', N'Singapore', N'SG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (203, 703, N'Словакия', N'Slovakia', N'SK')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (204, 704, N'Вьетнам', N'Vietnam', N'VN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (205, 705, N'Словения', N'Slovenia', N'SI')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (206, 706, N'Сомали', N'Somalia', N'SO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (207, 710, N'Южная Африка', N'South Africa', N'ZA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (208, 716, N'Зимбабве', N'Zimbabwe', N'ZW')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (209, 724, N'Испания', N'Spain', N'ES')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (210, 728, N'Южный Судан', N'South Sudan', N'SS')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (211, 729, N'Судан', N'Sudan', N'SD')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (212, 732, N'Западная Сахара', N'Western Sahara', N'EH')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (213, 740, N'Суринам', N'Suriname', N'SR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (214, 744, N'Шпицберген и Ян Майен', N'Svalbard and Jan Mayen', N'SJ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (215, 748, N'Свазиленд', N'Swaziland', N'SZ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (216, 752, N'Швеция', N'Sweden', N'SE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (217, 756, N'Швейцария', N'Switzerland', N'CH')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (218, 760, N'Сирийская Арабская Республика', N'Syrian Arab Republic', N'SY')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (219, 762, N'Таджикистан', N'Tajikistan', N'TJ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (220, 764, N'Таиланд', N'Thailand', N'TH')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (221, 768, N'Того', N'Togo', N'TG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (222, 772, N'Токелау', N'Tokelau', N'TK')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (223, 776, N'Тонга', N'Tonga', N'TO')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (224, 780, N'Тринидад и Тобаго', N'Trinidad and Tobago', N'TT')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (225, 784, N'Объединенные Арабские Эмираты', N'United Arab Emirates', N'AE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (226, 788, N'Тунис', N'Tunisia', N'TN')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (227, 792, N'Турция', N'Turkey', N'TR')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (228, 795, N'Туркмения', N'Turkmenistan', N'TM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (229, 796, N'Острова Теркс и Кайкос', N'Turks and Caicos Islands', N'TC')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (230, 798, N'Тувалу', N'Tuvalu', N'TV')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (231, 800, N'Уганда', N'Uganda', N'UG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (232, 804, N'Украина', N'Ukraine', N'UA')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (233, 807, N'Республика Македония', N'Macedonia, The Former Yugoslav Republic Of', N'MK')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (234, 818, N'Египет', N'Egypt', N'EG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (235, 826, N'Соединенное Королевство', N'United Kingdom', N'GB')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (236, 831, N'Гернси', N'Guernsey', N'GG')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (237, 832, N'Джерси', N'Jersey', N'JE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (238, 833, N'Остров Мэн', N'Isle of Man', N'IM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (239, 834, N'Танзания, Объединенная Республика', N'Tanzania, United Republic Of', N'TZ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (240, 840, N'Соединенные Штаты', N'United States', N'US')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (241, 850, N'Виргинские острова, США', N'Virgin Islands, U.S.', N'VI')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (242, 854, N'Буркина-Фасо', N'Burkina Faso', N'BF')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (243, 858, N'Уругвай', N'Uruguay', N'UY')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (244, 860, N'Узбекистан', N'Uzbekistan', N'UZ')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (245, 862, N'Венесуэла Боливарианская Республика', N'Venezuela', N'VE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (246, 876, N'Уоллис и Футуна', N'Wallis and Futuna', N'WF')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (247, 882, N'Самоа', N'Samoa', N'WS')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (248, 887, N'Йемен', N'Yemen', N'YE')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (249, 894, N'Замбия', N'Zambia', N'ZM')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (250, 895, N'Абхазия', N'Abkhazia', N'AB')
GO
INSERT [dbo].[Страны] ([Код], [Код_страны], [Наименование], [Английское_название_страны], [Буквенный_код_страны]) VALUES (251, 896, N'Южная Осетия', N'South Ossetia', N'OS')
GO
SET IDENTITY_INSERT [dbo].[Страны] OFF
GO
ALTER TABLE [dbo].[АктивностиМероприятия]  WITH CHECK ADD  CONSTRAINT [FK_АктивностиМероприятия_Активности] FOREIGN KEY([Код_активности])
REFERENCES [dbo].[Активности] ([Код_активности])
GO
ALTER TABLE [dbo].[АктивностиМероприятия] CHECK CONSTRAINT [FK_АктивностиМероприятия_Активности]
GO
ALTER TABLE [dbo].[АктивностиМероприятия]  WITH CHECK ADD  CONSTRAINT [FK_АктивностиМероприятия_Мероприятия] FOREIGN KEY([Код_мероприятия])
REFERENCES [dbo].[Мероприятия] ([Код_мероприятия])
GO
ALTER TABLE [dbo].[АктивностиМероприятия] CHECK CONSTRAINT [FK_АктивностиМероприятия_Мероприятия]
GO
ALTER TABLE [dbo].[ЖюриАктивности]  WITH CHECK ADD  CONSTRAINT [FK_ЖюриАктивности_Активности] FOREIGN KEY([Код_активности])
REFERENCES [dbo].[Активности] ([Код_активности])
GO
ALTER TABLE [dbo].[ЖюриАктивности] CHECK CONSTRAINT [FK_ЖюриАктивности_Активности]
GO
ALTER TABLE [dbo].[ЖюриАктивности]  WITH CHECK ADD  CONSTRAINT [FK_ЖюриАктивности_Пользователи] FOREIGN KEY([Код_жюри])
REFERENCES [dbo].[Пользователи] ([Код_пользователя])
GO
ALTER TABLE [dbo].[ЖюриАктивности] CHECK CONSTRAINT [FK_ЖюриАктивности_Пользователи]
GO
ALTER TABLE [dbo].[Мероприятия]  WITH CHECK ADD  CONSTRAINT [FK_Мероприятия_Города] FOREIGN KEY([Код_города_проведения])
REFERENCES [dbo].[Города] ([Код])
GO
ALTER TABLE [dbo].[Мероприятия] CHECK CONSTRAINT [FK_Мероприятия_Города]
GO
ALTER TABLE [dbo].[Мероприятия]  WITH CHECK ADD  CONSTRAINT [FK_Мероприятия_Направления] FOREIGN KEY([Код_направления])
REFERENCES [dbo].[Направления] ([Код_направления])
GO
ALTER TABLE [dbo].[Мероприятия] CHECK CONSTRAINT [FK_Мероприятия_Направления]
GO
ALTER TABLE [dbo].[МодераторыМероприятия]  WITH CHECK ADD  CONSTRAINT [FK_МодераторыМероприятия_Мероприятия] FOREIGN KEY([Код_мероприятия])
REFERENCES [dbo].[Мероприятия] ([Код_мероприятия])
GO
ALTER TABLE [dbo].[МодераторыМероприятия] CHECK CONSTRAINT [FK_МодераторыМероприятия_Мероприятия]
GO
ALTER TABLE [dbo].[МодераторыМероприятия]  WITH CHECK ADD  CONSTRAINT [FK_МодераторыМероприятия_Пользователи] FOREIGN KEY([Код_модератора])
REFERENCES [dbo].[Пользователи] ([Код_пользователя])
GO
ALTER TABLE [dbo].[МодераторыМероприятия] CHECK CONSTRAINT [FK_МодераторыМероприятия_Пользователи]
GO
ALTER TABLE [dbo].[Пользователи]  WITH CHECK ADD  CONSTRAINT [FK_Пользователи_Роли] FOREIGN KEY([Код_роли])
REFERENCES [dbo].[Роли] ([Код_роли])
GO
ALTER TABLE [dbo].[Пользователи] CHECK CONSTRAINT [FK_Пользователи_Роли]
GO
ALTER TABLE [dbo].[Пользователи]  WITH CHECK ADD  CONSTRAINT [FK_Пользователи_Страны] FOREIGN KEY([Код_страны])
REFERENCES [dbo].[Страны] ([Код])
GO
ALTER TABLE [dbo].[Пользователи] CHECK CONSTRAINT [FK_Пользователи_Страны]
GO
ALTER TABLE [dbo].[УчастникиМероприятия]  WITH CHECK ADD  CONSTRAINT [FK_УчастникиМероприятия_Мероприятия] FOREIGN KEY([Код_мероприятия])
REFERENCES [dbo].[Мероприятия] ([Код_мероприятия])
GO
ALTER TABLE [dbo].[УчастникиМероприятия] CHECK CONSTRAINT [FK_УчастникиМероприятия_Мероприятия]
GO
ALTER TABLE [dbo].[УчастникиМероприятия]  WITH CHECK ADD  CONSTRAINT [FK_УчастникиМероприятия_Пользователи] FOREIGN KEY([Код_участника])
REFERENCES [dbo].[Пользователи] ([Код_пользователя])
GO
ALTER TABLE [dbo].[УчастникиМероприятия] CHECK CONSTRAINT [FK_УчастникиМероприятия_Пользователи]
GO
USE [master]
GO
ALTER DATABASE [Конференции] SET  READ_WRITE 
GO
